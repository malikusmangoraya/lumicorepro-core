import sqlite3
import threading
import time
from typing import Dict, Any, List, Optional
from config.settings import AGENT_DB_PATH, REGISTRY_DIR
from utils.logger import agent_logger
from utils.helpers import extract_keywords, normalize_text
from utils.file_manager import FileManager

# Thread-local storage for DB connections
_thread_local = threading.local()

class MemoryRetriever:
    """Local-First Memory Retriever with thread-safe connections, WAL journal mode, and busy lock retries."""

    def __init__(self, db_path: str = None):
        self.db_path = db_path or str(AGENT_DB_PATH)

    def _get_connection(self) -> sqlite3.Connection:
        """Get thread-local SQLite connection with WAL mode and busy timeout configured."""
        if not hasattr(_thread_local, "connection") or _thread_local.connection is None:
            conn = sqlite3.connect(self.db_path, timeout=10.0)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("PRAGMA journal_mode=WAL;")
            cursor.execute("PRAGMA busy_timeout=5000;")
            _thread_local.connection = conn
        return _thread_local.connection

    def _execute_write_retry(self, query: str, params: tuple = ()) -> None:
        """Execute write query with max 3 retries on SQLite lock operational errors."""
        max_retries = 3
        for attempt in range(1, max_retries + 1):
            try:
                conn = self._get_connection()
                cursor = conn.cursor()
                cursor.execute(query, params)
                conn.commit()
                return
            except sqlite3.OperationalError as e:
                if "locked" in str(e).lower() and attempt < max_retries:
                    agent_logger.warning(f"SQLite DB locked (attempt {attempt}/{max_retries}). Retrying write...")
                    time.sleep(0.1 * (2 ** attempt))
                else:
                    agent_logger.error(f"SQLite operational write error: {e}")
                    raise e

    def search_templates(self, category: str, industry: str, features: List[str]) -> List[Dict[str, Any]]:
        """Search and score templates matching category, industry, and features with synonym expansion."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM templates_index")
            rows = cursor.fetchall()

            # Industry & Category Synonym Map
            synonyms = {
                "business": ["corporate", "agency", "company", "business"],
                "realestate": ["property", "house", "listings", "realestate"],
                "restaurant": ["cafe", "food", "dining", "restaurant"],
                "portfolio": ["personal", "brand", "resume", "portfolio"],
                "education": ["elearning", "lms", "course", "education"],
                "healthcare": ["medical", "clinic", "doctor", "healthcare"],
                "fitness": ["gym", "workout", "fitness"],
                "travel": ["tourism", "tours", "travel"],
                "creative": ["agency", "studio", "creative"],
                "ecommerce": ["store", "retail", "shop", "electronics", "ecommerce"]
            }

            expanded_cats = synonyms.get(category.lower(), [category.lower()])
            expanded_inds = synonyms.get(industry.lower(), [industry.lower()])

            results = []
            for row in rows:
                item = dict(row)
                score = 0
                item_cat = item["category"].lower()
                item_ind = item["industry"].lower()
                item_tags = [t.strip().lower() for t in item["tags"].split(",") if t.strip()]
                item_features = [f.strip().lower() for f in item["features"].split(",") if f.strip()]
                item_name = item["name"].lower()

                if item_cat in expanded_cats or category.lower() in item_cat:
                    score += 50
                if item_ind in expanded_inds or industry.lower() in item_ind:
                    score += 30

                for syn in expanded_cats + expanded_inds:
                    if syn in item_name or any(syn in t for t in item_tags):
                        score += 15

                for f in features:
                    if f.lower() in item_features or any(f.lower() in t for t in item_tags):
                        score += 10

                item["score"] = score
                results.append(item)

            results.sort(key=lambda x: x["score"], reverse=True)
            return results
        except Exception as e:
            agent_logger.error(f"Error searching templates: {e}")
            return []


    def search_components(self, category: str, features: List[str], keywords: List[str]) -> List[Dict[str, Any]]:
        """Search and rank components from local SQLite registry index."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM components_index")
            rows = cursor.fetchall()

            matched = []
            for row in rows:
                item = dict(row)
                score = 0
                comp_tags = [t.strip().lower() for t in item["tags"].split(",") if t.strip()]
                comp_features = [f.strip().lower() for f in item["features"].split(",") if f.strip()]

                if item["category"].lower() in [category.lower(), "common", "ui"]:
                    score += 20

                for feat in features:
                    if feat.lower() in comp_features or any(feat.lower() in t for t in comp_tags):
                        score += 25

                for kw in keywords:
                    if kw.lower() in item["name"].lower() or any(kw.lower() in t for t in comp_tags):
                        score += 15

                if score > 0:
                    item["score"] = score
                    matched.append(item)

            matched.sort(key=lambda x: x["score"], reverse=True)
            return matched
        except Exception as e:
            agent_logger.error(f"Error searching components: {e}")
            return []

    def search_assets(self, industry: str, asset_types: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        """Retrieve local icons, images, and animations matching industry and category."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM assets_index")
            rows = cursor.fetchall()

            categorized = {"images": [], "icons": [], "animations": []}
            for row in rows:
                item = dict(row)
                atype = item["type"]
                if atype == "image":
                    categorized["images"].append(item)
                elif atype == "icon":
                    categorized["icons"].append(item)
                elif atype == "animation":
                    categorized["animations"].append(item)

            return categorized
        except Exception as e:
            agent_logger.error(f"Error searching assets: {e}")
            return {"images": [], "icons": [], "animations": []}

    def search_backend(self, category: str, features: List[str]) -> Optional[Dict[str, Any]]:
        """Find best matching backend template and its modules."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM backend_index WHERE category = ?", (category,))
            row = cursor.fetchone()

            if row:
                res = dict(row)
                res["modules"] = [m.strip() for m in res["modules"].split(",") if m.strip()]
                return res

            cursor.execute("SELECT * FROM backend_index")
            rows = cursor.fetchall()

            if rows:
                res = dict(rows[0])
                res["modules"] = [m.strip() for m in res["modules"].split(",") if m.strip()]
                return res
            return None
        except Exception as e:
            agent_logger.error(f"Error searching backend: {e}")
            return None

    def search_database_schemas(self, features: List[str], industry: str) -> List[Dict[str, Any]]:
        """Retrieve matching database SQL schemas."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM database_schemas_index")
            rows = cursor.fetchall()

            matched = []
            for row in rows:
                item = dict(row)
                schema_features = [f.strip().lower() for f in item["features"].split(",") if f.strip()]
                score = 0
                for f in features:
                    if f.lower() in schema_features or item["category"].lower() in [f.lower(), industry.lower()]:
                        score += 30
                if score > 0 or item["category"] in ["auth", "ecommerce", industry]:
                    item["score"] = score
                    matched.append(item)

            matched.sort(key=lambda x: x["score"], reverse=True)
            return matched
        except Exception as e:
            agent_logger.error(f"Error searching database schemas: {e}")
            return []

    def record_search(self, query: str, summary: str, matches_count: int) -> None:
        """Log search history to database with lock retry logic."""
        q = "INSERT INTO search_history (query, result_summary, matches_count) VALUES (?, ?, ?)"
        self._execute_write_retry(q, (query, summary, matches_count))
