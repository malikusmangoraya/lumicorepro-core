import os
import json
import time
import traceback
from pathlib import Path
from typing import Dict, Any, Optional, List, Callable

from utils.logger import agent_logger
from utils.file_manager import FileManager
from config.providers import instantiate_provider, validate_provider_key, FALLBACK_ORDER
from config.settings import GENERATED_PROJECTS_DIR

from .memory_retriever import MemoryRetriever
from .requirement_analyzer import RequirementAnalyzer
from .market_analyzer import MarketAnalyzer
from .tech_stack_selector import TechStackSelector
from .trending_features import TrendingFeaturesInjector
from .planner import GenerationPlanner
from .template_selector import TemplateSelector
from .component_selector import ComponentSelector
from .asset_selector import AssetSelector
from .backend_selector import BackendSelector
from .database_selector import DatabaseSelector
from .project_builder import ProjectBuilder
from .code_modifier import CodeModifier
from .validator import ProjectValidator
from .quality_gates import QualityGates
from .improvement_recommender import ImprovementRecommender
from .competitive_benchmark import CompetitiveBenchmark
from .currency_localizer import CurrencyLocalizer
from .compliance_generator import ComplianceGenerator
from .accessibility_checker import AccessibilityChecker
from .localization_engine import LocalizationEngine
from .api_generator import APIGenerator
from .seo_automation import SEOAutomationEngine
from .cdn_optimizer import CDNOptimizer
from .performance_budget import PerformanceBudgetEngine
from .analytics_pipeline import AnalyticsPipeline
from .ab_testing_engine import ABTestingEngine
from .webhook_manager import WebhookManager
from .global_deployment import GlobalDeploymentEngine


class OrchestratorError(Exception):
    """Raised when pipeline execution encounters unrecoverable errors."""
    pass


class PhaseError(Exception):
    """Raised when a specific phase fails."""
    def __init__(self, phase_name: str, error: Exception):
        self.phase_name = phase_name
        self.error = error
        super().__init__(f"Phase '{phase_name}' failed: {error}")


class AgentOrchestrator:
    """Master controller — 15-phase state-of-the-art enterprise AI project generation pipeline."""

    PHASES = [
        "market_analysis",
        "requirement_analysis",
        "tech_stack_selection",
        "trending_features_injection",
        "resource_assembly_planning",
        "code_generation",
        "quality_verification",
        "improvement_recommendations",
        "competitive_benchmark_delivery",
        "international_delivery",
        "localization_and_i18n",
        "compliance_and_accessibility",
        "seo_and_cdn_optimization",
        "performance_growth_and_webhooks",
        "multi_cloud_global_deployment",
    ]

    CRITICAL_PHASES = {
        "requirement_analysis",
        "resource_assembly_planning",
        "code_generation",
    }
    NON_CRITICAL_FAILURE_LIMIT = 5
    RETRYABLE_PHASES = {
        "market_analysis",
        "trending_features_injection",
        "quality_verification",
        "improvement_recommendations",
        "competitive_benchmark_delivery",
    }
    MAX_RETRIES = 2
    PHASE_TIMEOUT_SECS = 120

    # Phase dependency graph
    PHASE_DEPENDENCIES = {
        "requirement_analysis": [],
        "tech_stack_selection": ["requirement_analysis"],
        "trending_features_injection": ["requirement_analysis", "market_analysis"],
        "resource_assembly_planning": ["requirement_analysis", "tech_stack_selection"],
        "code_generation": ["resource_assembly_planning"],
        "quality_verification": ["code_generation"],
        "improvement_recommendations": ["quality_verification"],
        "competitive_benchmark_delivery": ["quality_verification", "market_analysis"],
        "international_delivery": ["code_generation"],
        "localization_and_i18n": ["code_generation"],
        "compliance_and_accessibility": ["code_generation"],
        "seo_and_cdn_optimization": ["code_generation"],
        "performance_growth_and_webhooks": ["code_generation"],
        "multi_cloud_global_deployment": ["code_generation"],
    }

    def __init__(self, provider_name: Optional[str] = None):
        self.ai_provider = self._init_provider(provider_name)
        self.memory_retriever = MemoryRetriever()
        self.phase_timings: Dict[str, float] = {}
        self.retry_counts: Dict[str, int] = {}
        self.progress_callback: Optional[Callable[[str, str, Dict[str, Any]], None]] = None

        # Core generation agents
        self.market_analyzer = MarketAnalyzer()
        self.analyzer = RequirementAnalyzer(self.ai_provider)
        self.tech_stack_selector = TechStackSelector()
        self.trending_injector = TrendingFeaturesInjector()
        self.planner = GenerationPlanner()
        self.template_selector = TemplateSelector(self.memory_retriever)
        self.component_selector = ComponentSelector(self.memory_retriever)
        self.asset_selector = AssetSelector(self.memory_retriever)
        self.backend_selector = BackendSelector(self.memory_retriever)
        self.database_selector = DatabaseSelector(self.memory_retriever)
        self.project_builder = ProjectBuilder()
        self.code_modifier = CodeModifier(self.ai_provider)
        self.validator = ProjectValidator()
        self.quality_gates = QualityGates()
        self.improvement_recommender = ImprovementRecommender()
        self.competitive_benchmark = CompetitiveBenchmark()

        # International, compliance & accessibility engines
        self.currency_localizer = CurrencyLocalizer()
        self.compliance_generator = ComplianceGenerator()
        self.accessibility_checker = AccessibilityChecker()
        self.localization_engine = LocalizationEngine()

        # Enterprise REST API, SEO, CDN, Performance, Analytics, A/B Testing & Cloud Engines
        self.api_generator = APIGenerator()
        self.seo_engine = SEOAutomationEngine()
        self.cdn_optimizer = CDNOptimizer()
        self.performance_budget = PerformanceBudgetEngine()
        self.analytics_pipeline = AnalyticsPipeline()
        self.ab_testing_engine = ABTestingEngine()
        self.webhook_manager = WebhookManager()
        self.deployment_engine = GlobalDeploymentEngine()

    def _init_provider(self, provider_name: Optional[str] = None):
        """Instantiate configured AI provider instance dynamically with fallback chain support."""
        primary_name = provider_name or os.getenv("ACTIVE_AI_PROVIDER", "gemini").lower()
        candidates = [primary_name] + [p for p in FALLBACK_ORDER if p != primary_name]

        for p_name in candidates:
            try:
                if validate_provider_key(p_name, require_key=False):
                    provider_inst = instantiate_provider(p_name)
                    if provider_inst:
                        agent_logger.info(f"Initialized AI Provider: '{p_name}'")
                        return provider_inst
            except Exception as e:
                agent_logger.warning(f"Provider '{p_name}' initialization failed ({e}). Trying next fallback...")

        agent_logger.info("No external AI provider API keys configured. Operating in local-first offline mode.")
        return None

    def _run_phase(self, phase_name: str, func, *args, **kwargs) -> Any:
        """Execute a single phase with error isolation, retry logic, recovery fallback, timing, and callbacks."""
        retries = kwargs.pop("_retries", 0)
        fallback = kwargs.pop("_fallback", None)
        is_critical = kwargs.pop("_critical", False)
        is_retryable = kwargs.pop("_retryable", False)

        if is_retryable and retries == 0:
            retries = self.MAX_RETRIES

        self.retry_counts[phase_name] = retries
        initial_retries = retries

        agent_logger.info(f"[PHASE START] ---- {phase_name}")
        if self.progress_callback:
            try:
                self.progress_callback(phase_name, "phase_start", {"ts": time.time()})
            except Exception:
                pass

        phase_start = time.time()
        try:
            result = func(*args, **kwargs)
            phase_time = round(time.time() - phase_start, 3)
            self.phase_timings[phase_name] = phase_time
            retries_used = initial_retries - retries
            if retries_used > 0:
                agent_logger.info(f"[PHASE COMPLETE] {phase_name} (took {phase_time}s) — Succeeded after {retries_used} retry attempt(s)")
            else:
                agent_logger.info(f"[PHASE COMPLETE] {phase_name} (took {phase_time}s)")

            if self.progress_callback:
                try:
                    self.progress_callback(phase_name, "phase_done", {"ts": time.time(), "duration": phase_time})
                except Exception:
                    pass
            return result
        except Exception as e:
            phase_time = round(time.time() - phase_start, 3)
            self.phase_timings[phase_name] = phase_time
            error_trace = traceback.format_exc()
            agent_logger.error(f"[PHASE FAILED] {phase_name} (took {phase_time}s) — {e}")
            agent_logger.debug(f"[PHASE TRACE] {phase_name}:\n{error_trace}")

            if self.progress_callback:
                try:
                    self.progress_callback(phase_name, "phase_error", {"ts": time.time(), "error": str(e)})
                except Exception:
                    pass

            if retries > 0:
                agent_logger.warning(f"[PHASE RETRY] Retrying {phase_name} ({retries - 1} attempts left)...")
                return self._run_phase(phase_name, func, *args, _retries=retries - 1,
                                       _fallback=fallback,
                                       _critical=is_critical,
                                       _retryable=is_retryable,
                                       **kwargs)
            if is_critical:
                agent_logger.critical(f"[PHASE CRITICAL FAILURE] {phase_name} failed with no fallback. Pipeline cannot continue.")
                raise OrchestratorError(f"Critical phase '{phase_name}' failed: {e}")
            if fallback is not None:
                agent_logger.info(f"[PHASE FALLBACK] Using fallback for {phase_name}")
                return fallback
            agent_logger.error(f"[PHASE UNRECOVERABLE] {phase_name} failed with no fallback.")
            raise

    def _run_phase_safe(self, phase_name: str, func, func_args=None, fallback=None, critical=False, retryable=False):
        """Run a phase and only recover automatically when it is non-critical."""
        args = func_args or []
        try:
            return self._run_phase(phase_name, func, *args, _critical=critical, _retryable=retryable, _fallback=fallback)
        except Exception as e:
            agent_logger.error(f"[PHASE CAUGHT] {phase_name} final fallback: {e}")
            if critical:
                raise
            return fallback if fallback is not None else None

    def _reset_phase_tracking(self):
        """Reset phase tracking state between pipeline runs."""
        self.phase_timings = {}
        self.retry_counts = {}

    def _get_project_main_files(self, project_dir: str, max_files: int = 10) -> List[str]:
        """Discover key project files for AI modification by searching frontend/src."""
        src_dir = os.path.join(project_dir, "frontend", "src")
        files: List[str] = []
        if not os.path.isdir(src_dir):
            return []
        for root, _, filenames in os.walk(src_dir):
            for fname in filenames:
                if fname.endswith((".jsx", ".tsx", ".js", ".ts")):
                    files.append(os.path.join(root, fname))
        return files[:max_files]

    def _calculate_health(self, phase_failures: List[str]) -> Dict[str, Any]:
        """Calculate pipeline health score based on failures and critical phase impact."""
        health = 100
        critical_failures = [f for f in phase_failures if f in {"phase_2_requirement_analysis",
                                                                 "phase_5_assembly_planning",
                                                                 "phase_6_code_generation"}]
        non_critical_failures = [f for f in phase_failures if f not in critical_failures]

        health -= len(critical_failures) * 20
        health -= len(non_critical_failures) * 4

        return {
            "score": max(0, health),
            "critical_failures": critical_failures,
            "non_critical_failures": non_critical_failures,
            "status": "healthy" if health >= 80 else "degraded" if health >= 50 else "critical",
        }

    def _phase_failure_names(self, phase_failures: List[str]) -> set:
        """Map report identifiers such as phase_6_code_generation to canonical phase IDs."""
        return {
            failure.split("_", 2)[-1]
            for failure in phase_failures
            if failure.startswith("phase_") and "_" in failure
        }

    def _collect_user_design_preferences(
        self,
        spec: Dict[str, Any],
        market_analysis: Optional[Dict[str, Any]] = None,
        interactive: bool = False,
    ) -> Dict[str, Any]:
        """Consolidated design customization flow. Supports interactive CLI or automated defaults."""
        website_type = spec.get("website_type", "ecommerce")
        industry = spec.get("industry", "general")
        project_name = spec.get("project_name", "my-project")

        # Smart defaults based on industry & website type
        defaults = {
            "animation_style": "modern",
            "color_scheme": "cyan" if website_type in ("saas", "dashboard", "fintech") else "dark",
            "layout_style": "multi_page",
            "font_style": "sans_serif",
            "pages": spec.get("pages", ["Home", "About", "Services", "Contact"]),
            "extra_features": ["cookie_consent", "responsive_navbar", "dark_mode_toggle"],
        }

        if not interactive:
            spec.update(defaults)
            return spec

        print("\n" + "=" * 65)
        print("   🎨 LUMICOREPRO ENTERPRISE DESIGN CUSTOMIZER")
        print("=" * 65)
        print(f"  📌 Project Type  : {website_type.title()} Website")
        print(f"  🏭 Industry      : {industry.title()}")
        print(f"  📁 Project Name  : {project_name}")

        try:
            # 1. Animation Style
            print("\n  [1/4] ANIMATION STYLE:")
            print("     (1) Modern & Clean (smooth micro-interactions)")
            print("     (2) Glassmorphism (frosted glass panels & blur)")
            print("     (3) Minimal (fast, subtle transitions)")
            print("     (4) Bold Dynamic (parallax & scroll effects)")
            anim_choice = input("     Select choice (1-4, default=1): ").strip()
            animation_map = {"1": "modern", "2": "glassmorphism", "3": "minimal", "4": "bold"}
            selected_anim = animation_map.get(anim_choice, "modern")

            # 2. Color Theme
            print("\n  [2/4] COLOR SCHEME:")
            print("     (1) Dark Mode (Slate & Cyan Accent)")
            print("     (2) Clean Light (White & Indigo Accent)")
            print("     (3) Emerald Green (Organic / Modern)")
            print("     (4) Sunset Amber (Warm & Creative)")
            color_choice = input("     Select choice (1-4, default=1): ").strip()
            color_map = {"1": "dark_cyan", "2": "clean_light", "3": "emerald", "4": "sunset"}
            selected_color = color_map.get(color_choice, "dark_cyan")

            # 3. Extra Pages
            print("\n  [3/4] ADDITIONAL PAGES (comma-separated, or Enter to use defaults):")
            extra_pages_in = input("     Extra pages: ").strip()
            if extra_pages_in:
                pages_list = [p.strip() for p in extra_pages_in.split(",") if p.strip()]
                spec["pages"] = list(set(spec.get("pages", []) + pages_list))

            # 4. Confirmation
            confirm = input("\n  ✅ Type 'build' or press Enter to generate project: ").strip().lower()
            if confirm in ("cancel", "exit", "quit", "n", "no"):
                print("  ❌ Generation cancelled by user.")
                raise KeyboardInterrupt("Cancelled by user")

            spec["animation_style"] = selected_anim
            spec["color_scheme"] = selected_color
            print(f"  🚀 Plan approved! Building '{project_name}'...\n")
        except (EOFError, KeyboardInterrupt):
            agent_logger.info("Non-interactive / input stream closed. Using smart defaults.")
            spec.update(defaults)

        return spec

    # Backwards-compatible aliases
    _interactive_plan_approval = _collect_user_design_preferences
    _ask_design_preferences = _collect_user_design_preferences
    _interact_with_user = _collect_user_design_preferences

    def _safe_zip(self, project_dir: str, spec: Dict[str, Any]) -> str:
        """Create ZIP archive safely; returns empty string on failure."""
        try:
            zip_output_base = os.path.join(
                os.path.dirname(project_dir),
                spec.get("project_name", "generated-website")
            )
            return FileManager.create_zip_archive(project_dir, zip_output_base)
        except Exception as e:
            agent_logger.error(f"ZIP archive creation failed: {e}")
            return ""

    def _build_report(
        self, *,
        start_time: float,
        prompt: str,
        spec: Dict[str, Any],
        project_dir: str,
        phase_log: Dict[str, Any],
        phase_failures: list,
        selected_template,
        selected_components: list,
        selected_assets: Dict[str, list],
        selected_backend,
        selected_schemas: list,
        tech_stack: Dict[str, Any],
        trending_result: Dict[str, Any],
        ai_calls_count: int,
        validation_report: Dict[str, Any],
        quality_report: Dict[str, Any],
        improvements: Dict[str, Any],
        benchmark: Dict[str, Any],
        zip_archive_path: str,
    ) -> Dict[str, Any]:
        instructions_file_path = os.path.join(project_dir, "INSTRUCTIONS.md")
        execution_time = round(time.time() - start_time, 2)

        failed_phase_names = self._phase_failure_names(phase_failures)
        critical_failure = any(
            name in self.CRITICAL_PHASES for name in failed_phase_names
        )
        report = {
            "user_prompt": prompt,
            "project_name": spec.get("project_name", "generated-website"),
            "generated_project_dir": project_dir,
            "zip_archive_path": zip_archive_path,
            "instructions_file_path": instructions_file_path,
            "execution_time_seconds": execution_time,
            "pipeline_version": "15-phase-enterprise-v3.5",
            "status": "failed" if critical_failure else "partial" if phase_failures else "succeeded",
            "pipeline_health": self._calculate_health(phase_failures),
            "phase_statistics": {
                "total_phases": len(self.PHASES),
                "phases_failed": len(phase_failures),
                "phase_timings": self.phase_timings,
                "retries_per_phase": self.retry_counts,
            },
            "phases_completed": [p for p in self.PHASES if p not in failed_phase_names],
            "phase_failures": phase_failures,
            "phase_results": phase_log,
            "selected_resources": {
                "template": selected_template.get("name") if selected_template else "Default Base",
                "components_count": len(selected_components),
                "components": [c["name"] for c in selected_components],
                "images_count": len(selected_assets.get("images", [])),
                "icons_count": len(selected_assets.get("icons", [])),
                "animations_count": len(selected_assets.get("animations", [])),
                "backend": selected_backend.get("name") if selected_backend else "Default Express",
                "database_schemas": [s.get("name") for s in selected_schemas],
                "tech_stack": tech_stack,
                "trending_features": trending_result.get("feature_ids", []),
            },
            "ai_api_calls_made": ai_calls_count,
            "validation_results": validation_report,
            "quality_gates": quality_report,
            "improvement_recommendations": improvements,
            "competitive_benchmark": benchmark,
            "enterprise_ready": quality_report.get("enterprise_ready", False),
            "launch_ready": benchmark.get("launch_ready", False),
            # ── Enterprise Capabilities ────────────────────────────────
            "international": {
                "region":                  spec.get("region", "NA"),
                "primary_currency":        phase_log.get("phase_11_localization", {}).get("primary_currency", "USD"),
                "payment_gateways":        phase_log.get("phase_11_localization", {}).get("payment_gateways", ["Stripe"]),
                "languages_generated":     phase_log.get("phase_11_localization", {}).get("languages_generated", ["en"]),
                "total_languages":         phase_log.get("phase_11_localization", {}).get("total_languages", 1),
                "rtl_support":             spec.get("rtl_support", False),
                "rtl_languages":           phase_log.get("phase_11_localization", {}).get("rtl_languages", []),
                "compliance_regs":         phase_log.get("phase_12_compliance_accessibility", {}).get("compliance_regs", []),
                "compliance_artifacts":    phase_log.get("phase_12_compliance_accessibility", {}).get("compliance_artifacts", 0),
                "requires_consent_banner": phase_log.get("phase_12_compliance_accessibility", {}).get("requires_consent_banner", False),
                "accessibility_score":     phase_log.get("phase_12_compliance_accessibility", {}).get("accessibility_score", 0),
                "wcag_aa_compliant":       phase_log.get("phase_12_compliance_accessibility", {}).get("wcag_aa_compliant", False),
            },
            "seo_and_edge": phase_log.get("phase_13_seo_and_cdn", {}),
            "performance_and_growth": phase_log.get("phase_14_performance_growth", {}),
            "multi_cloud_deployment": phase_log.get("phase_15_global_deployment", {}),
        }

        report_path = os.path.join(project_dir, "generation-report.json")
        try:
            FileManager.write_json(report_path, report)
        except Exception as e:
            agent_logger.error(f"Failed to write generation-report.json: {e}")

        return report

    def run(
        self,
        prompt: str,
        interactive: bool = False,
        progress_callback: Optional[Callable[[str, str, Dict[str, Any]], None]] = None,
    ) -> Dict[str, Any]:
        """Execute 15-phase enterprise project generation pipeline with error isolation and callbacks."""
        self._reset_phase_tracking()
        self.progress_callback = progress_callback
        start_time = time.time()
        phase_log: Dict[str, Any] = {}
        phase_failures: List[str] = []

        # Defaults for downstream safety
        market_analysis = {}
        spec = {}
        tech_stack = {}
        trending_result = {"injected_count": 0, "feature_ids": [], "required_components": []}
        selected_template = None
        selected_components: list = []
        selected_assets = {"images": [], "icons": [], "animations": []}
        selected_backend = {
            "name": "E-Commerce Modular Base API",
            "file_path": "backend-library/ecommerce-base",
        }
        selected_schemas: list = []
        project_dir = ""
        ai_calls_count = 0
        validation_report = {"valid": True, "errors": [], "warnings": []}
        quality_report = {"overall_score": 0, "enterprise_ready": False}
        improvements = {"total_recommendations": 0, "recommendations": []}
        benchmark = {"launch_ready": False}
        plan = {
            "project_name": "generated-website",
            "assembly_steps": [],
            "ai_tasks_required": [],
            "template": {},
            "components": [],
            "assets": {},
            "backend": {},
            "database_schemas": [],
        }

        agent_logger.info("==================================================")
        agent_logger.info("  LUMICOREPRO 15-PHASE ENTERPRISE GENERATION AGENT")
        agent_logger.info("==================================================")
        agent_logger.info(f"User Prompt: '{prompt}'")

        # ── Phase 1: Market Analysis ─────────────────────────────────────────
        try:
            prelim_spec = self._run_phase_safe(
                "Phase 1 - Market Analysis",
                self.analyzer._local_rule_analysis,
                func_args=[prompt],
                fallback={"website_type": "ecommerce", "industry": "general", "features": []}
            )
            market_analysis = self._run_phase_safe(
                "Phase 1 - Market Analysis",
                self.market_analyzer.analyze,
                func_args=[prelim_spec],
                fallback={}
            )
            phase_log["phase_1_market_analysis"] = market_analysis
        except Exception:
            phase_failures.append("phase_1_market_analysis")

        # ── Phase 2: Requirement Analysis ────────────────────────────────────
        try:
            spec = self._run_phase_safe(
                "Phase 2 - Requirement Analysis",
                self.analyzer.analyze,
                func_args=[prompt],
                fallback={"is_ambiguous": False, "website_type": "ecommerce",
                           "industry": "general", "features": [], "project_name": ""},
                critical=True
            )
            if spec.get("is_ambiguous"):
                agent_logger.warning(f"PROMPT AMBIGUITY DETECTED: {spec.get('ambiguity_reason')}")
                if interactive:
                    print("\n[CLARIFICATION REQUIRED]")
                    print(f"Reason: {spec.get('ambiguity_reason')}")
                    for opt in spec.get("clarifying_options", []):
                        print(f"  {opt}")
                    new_prompt = input("\nPlease re-enter a clarified prompt:\n> ").strip()
                    if new_prompt:
                        prompt = new_prompt
                        spec = self._run_phase_safe(
                            "Phase 2 - Requirement Analysis (retry)",
                            self.analyzer.analyze,
                            func_args=[prompt],
                            fallback=spec
                        )
            # Apply design preferences
            spec = self._collect_user_design_preferences(spec, market_analysis, interactive=interactive)
            phase_log["phase_2_requirement_analysis"] = spec
        except Exception:
            phase_failures.append("phase_2_requirement_analysis")

        # ── Phase 3: Tech Stack & Architecture Selection ─────────────────────
        try:
            selected_backend = self._run_phase_safe(
                "Phase 3 - Backend Selection",
                self.backend_selector.select_backend,
                func_args=[spec],
                fallback={"name": "E-Commerce Modular Base API", "file_path": "backend-library/ecommerce-base"}
            )
            selected_schemas = self._run_phase_safe(
                "Phase 3 - Schema Selection",
                self.database_selector.select_schemas,
                func_args=[spec],
                fallback=[]
            )
            tech_stack = self._run_phase_safe(
                "Phase 3 - Tech Stack Selection",
                self.tech_stack_selector.select,
                func_args=[spec, selected_backend, selected_schemas],
                fallback={}
            )
            phase_log["phase_3_tech_stack"] = tech_stack
        except Exception:
            phase_failures.append("phase_3_tech_stack")

        # ── Phase 4: Trending Features Injection ─────────────────────────────
        try:
            trending_result = self._run_phase_safe(
                "Phase 4 - Trending Features",
                self.trending_injector.inject,
                func_args=[spec, market_analysis],
                fallback={"injected_count": 0, "feature_ids": [], "required_components": []},
                retryable=True
            )
            phase_log["phase_4_trending_features"] = trending_result
        except Exception:
            phase_failures.append("phase_4_trending_features")

        # ── Phase 5: Resource Assembly Planning ──────────────────────────────
        try:
            selected_template = self._run_phase_safe(
                "Phase 5 - Template Selection",
                self.template_selector.select_template,
                func_args=[spec],
                fallback=None,
                critical=True
            )
            selected_components = self._run_phase_safe(
                "Phase 5 - Component Selection",
                self.component_selector.select_components,
                func_args=[spec],
                fallback=[]
            )
            selected_assets = self._run_phase_safe(
                "Phase 5 - Asset Selection",
                self.asset_selector.select_assets,
                func_args=[spec],
                fallback={"images": [], "icons": [], "animations": []}
            )

            trending_components = trending_result.get("required_components", [])
            if trending_components:
                extra = self.component_selector.select_by_names(trending_components)
                existing_names = {c["name"] for c in selected_components}
                for comp in extra:
                    if comp["name"] not in existing_names:
                        selected_components.append(comp)

            plan = self.planner.create_plan(
                spec, selected_template, selected_components,
                selected_assets, selected_backend, selected_schemas,
            )
            plan["spec"] = spec
            phase_log["phase_5_assembly_plan"] = {
                "project_name": plan["project_name"],
                "steps": len(plan["assembly_steps"]),
                "ai_tasks": len(plan.get("ai_tasks_required", [])),
            }
        except Exception:
            phase_failures.append("phase_5_assembly_planning")

        # ── Phase 6: Code Generation & REST API Scaffolding ──────────────────
        try:
            plan["spec"] = spec
            project_dir = self.project_builder.build_project(plan)

            # Generate full enterprise REST API backend matching spec features
            if project_dir:
                backend_dir = Path(project_dir) / "backend"
                try:
                    self.api_generator.generate_full_backend(backend_dir, plan)
                except Exception as api_err:
                    agent_logger.warning(f"APIGenerator backend note: {api_err}")

            ai_calls_count = 0
            if plan.get("ai_tasks_required") and self.ai_provider:
                for task_item in plan["ai_tasks_required"]:
                    agent_logger.info(f"Executing AI customization: {task_item}")
                    project_files = self._get_project_main_files(project_dir)
                    for file_path in project_files:
                        if os.path.exists(file_path):
                            self.code_modifier.patch_file(file_path, task_item)
                            ai_calls_count += 1
                            if ai_calls_count >= 3:
                                break
            phase_log["phase_6_code_generation"] = {"project_dir": project_dir, "ai_calls": ai_calls_count}
        except Exception:
            phase_failures.append("phase_6_code_generation")

        # ── Phase 7: Quality Verification ────────────────────────────────────
        try:
            if project_dir:
                validation_report = self.validator.validate_project(project_dir)
                quality_report = self.quality_gates.evaluate(project_dir, spec, validation_report)
            phase_log["phase_7_quality_verification"] = quality_report
        except Exception:
            phase_failures.append("phase_7_quality_verification")

        # ── Phase 8: Improvement Recommendations ─────────────────────────────
        try:
            improvements = self.improvement_recommender.recommend(spec, quality_report, validation_report)
            phase_log["phase_8_improvements"] = improvements
        except Exception:
            phase_failures.append("phase_8_improvements")

        # ── Phase 9: Competitive Benchmark & ROI Scoring ─────────────────────
        try:
            benchmark = self.competitive_benchmark.benchmark(spec, market_analysis, quality_report, tech_stack)
            phase_log["phase_9_benchmark"] = benchmark
        except Exception:
            phase_failures.append("phase_9_benchmark")

        # ── Phase 10: International Delivery Meta ────────────────────────────
        try:
            if project_dir:
                expected_files = [
                    "docker-compose.yml",
                    "INSTRUCTIONS.md",
                    "DEPLOYMENT_CHECKLIST.md",
                    "SEO_META_TAGS.md",
                    ".github/workflows/deploy.yml",
                    "frontend/public/robots.txt",
                    "frontend/public/sitemap.xml",
                    "frontend/public/manifest.json",
                    "frontend/Dockerfile",
                    "backend/Dockerfile",
                ]
                delivery_status = {fname: "✅" if os.path.exists(os.path.join(project_dir, fname)) else "⚠️ missing" for fname in expected_files}
                phase_log["phase_10_international_delivery"] = {
                    "files_checked": len(expected_files),
                    "delivery_status": delivery_status,
                }
        except Exception as e:
            phase_failures.append("phase_10_international_delivery")

        # ── Phase 11: Multi-Currency & i18n Localization ─────────────────────
        try:
            currency_result = self._run_phase_safe(
                "phase_11_currency_localization",
                self.currency_localizer.localize,
                func_args=[spec],
                fallback={"region": "NA", "primary_currency": {"code": "USD"}, "payment_gateways": ["Stripe"]}
            )
            if currency_result:
                spec["region"] = currency_result.get("region", "NA")

            localization_result = {}
            if project_dir:
                localization_result = self._run_phase_safe(
                    "phase_11_i18n_generation",
                    self.localization_engine.generate,
                    func_args=[spec, project_dir],
                    fallback={"languages_generated": ["en"], "total_languages": 1}
                )

            phase_log["phase_11_localization"] = {
                "region": currency_result.get("region", "NA"),
                "primary_currency": currency_result.get("primary_currency", {}).get("code", "USD"),
                "payment_gateways": currency_result.get("payment_gateways", [])[:3],
                "languages_generated": localization_result.get("languages_generated", ["en"]),
                "total_languages": localization_result.get("total_languages", 1),
                "rtl_languages": localization_result.get("rtl_languages", []),
            }
        except Exception as e:
            phase_failures.append("phase_11_localization")

        # ── Phase 12: Compliance (GDPR/CCPA) & Accessibility (WCAG 2.1 AA) ──
        try:
            compliance_report = {}
            accessibility_report = {}
            if project_dir:
                region = spec.get("region", "NA")
                compliance_report = self._run_phase_safe(
                    "phase_12_compliance",
                    self.compliance_generator.generate,
                    func_args=[spec, project_dir, region],
                    fallback={"region": region, "applicable_regs": [], "artifacts_generated": []}
                )
                accessibility_report = self._run_phase_safe(
                    "phase_12_accessibility",
                    self.accessibility_checker.check,
                    func_args=[project_dir, spec],
                    fallback={"accessibility_score": 0, "wcag_aa_compliant": False}
                )

            phase_log["phase_12_compliance_accessibility"] = {
                "compliance_regs": compliance_report.get("reg_codes", []),
                "compliance_artifacts": len(compliance_report.get("artifacts_generated", [])),
                "requires_consent_banner": compliance_report.get("requires_consent_banner", False),
                "accessibility_score": accessibility_report.get("accessibility_score", 0),
                "wcag_aa_compliant": accessibility_report.get("wcag_aa_compliant", False),
            }
        except Exception:
            phase_failures.append("phase_12_compliance_accessibility")

        # ── Phase 13: SEO Suite & Edge CDN Rules ─────────────────────────────
        try:
            seo_report = {}
            cdn_report = {}
            if project_dir:
                seo_report = self._run_phase_safe(
                    "phase_13_seo_automation",
                    self.seo_engine.generate,
                    func_args=[spec, project_dir],
                    fallback={}
                )
                cdn_report = self._run_phase_safe(
                    "phase_13_cdn_optimization",
                    self.cdn_optimizer.generate,
                    func_args=[project_dir, spec],
                    fallback={}
                )
            phase_log["phase_13_seo_and_cdn"] = {
                "pages_optimized": seo_report.get("pages_optimized", 0),
                "sitemap_url": seo_report.get("sitemap_url", ""),
                "cdn_platforms": cdn_report.get("platforms_configured", []),
            }
        except Exception:
            phase_failures.append("phase_13_seo_and_cdn_optimization")

        # ── Phase 14: Performance, Webhooks & Conversion Growth ──────────────
        try:
            perf_report = {}
            analytics_report = {}
            ab_report = {}
            webhook_report = {}
            if project_dir:
                perf_report = self._run_phase_safe(
                    "phase_14_performance_budget",
                    self.performance_budget.generate,
                    func_args=[spec, project_dir],
                    fallback={}
                )
                analytics_report = self._run_phase_safe(
                    "phase_14_analytics_pipeline",
                    self.analytics_pipeline.generate,
                    func_args=[spec, project_dir],
                    fallback={}
                )
                ab_report = self._run_phase_safe(
                    "phase_14_ab_testing",
                    self.ab_testing_engine.generate,
                    func_args=[spec, project_dir],
                    fallback={}
                )
                webhook_report = self._run_phase_safe(
                    "phase_14_webhook_manager",
                    self.webhook_manager.generate,
                    func_args=[spec, project_dir],
                    fallback={}
                )
            phase_log["phase_14_performance_growth"] = {
                "performance_targets": perf_report.get("targets", {}),
                "analytics_events": analytics_report.get("total_events", 0),
                "ab_experiments": ab_report.get("total_experiments", 0),
                "webhook_events": webhook_report.get("total_events", 0),
            }
        except Exception:
            phase_failures.append("phase_14_performance_growth_and_webhooks")

        # ── Phase 15: Multi-Cloud Production Deployment ──────────────────────
        try:
            cloud_report = {}
            if project_dir:
                cloud_report = self._run_phase_safe(
                    "phase_15_global_deployment",
                    self.deployment_engine.generate,
                    func_args=[spec, project_dir],
                    fallback={}
                )
            phase_log["phase_15_global_deployment"] = {
                "supported_clouds": cloud_report.get("platforms_supported", ["vercel", "railway", "render", "aws", "gcp"]),
                "artifacts_count": len(cloud_report.get("artifacts", [])),
            }
        except Exception:
            phase_failures.append("phase_15_multi_cloud_global_deployment")

        # ── Safe ZIP Creation & Report Assembly ──────────────────────────────
        # Re-run validation after every artifact-producing phase so readiness is
        # based on the final project, not the pre-localization scaffold.
        if project_dir:
            try:
                validation_report = self.validator.validate_project(project_dir)
                quality_report = self.quality_gates.evaluate(project_dir, spec, validation_report)
                phase_log["final_production_validation"] = {
                    "valid": validation_report.get("valid", False),
                    "quality_score": quality_report.get("overall_score", 0),
                    "enterprise_ready": quality_report.get("enterprise_ready", False),
                }
            except Exception as exc:
                agent_logger.error(f"Final production validation failed: {exc}")
                phase_failures.append("final_production_validation")

        zip_archive_path = ""
        if project_dir:
            zip_archive_path = self._safe_zip(project_dir, spec)

        report = self._build_report(
            start_time=start_time,
            prompt=prompt,
            spec=spec,
            project_dir=project_dir,
            phase_log=phase_log,
            phase_failures=phase_failures,
            selected_template=selected_template,
            selected_components=selected_components,
            selected_assets=selected_assets,
            selected_backend=selected_backend,
            selected_schemas=selected_schemas,
            tech_stack=tech_stack,
            trending_result=trending_result,
            ai_calls_count=ai_calls_count,
            validation_report=validation_report,
            quality_report=quality_report,
            improvements=improvements,
            benchmark=benchmark,
            zip_archive_path=zip_archive_path,
        )

        execution_time = round(time.time() - start_time, 2)
        health = self._calculate_health(phase_failures)
        timings_summary = ", ".join(f"{k}: {v}s" for k, v in self.phase_timings.items())

        agent_logger.info("==================================================")
        agent_logger.info(f"  15-PHASE ENTERPRISE GENERATION COMPLETE IN {execution_time}s")
        agent_logger.info(
            f"  Quality Score: {quality_report.get('overall_score', 'N/A')}% | "
            f"Launch Ready: {benchmark.get('launch_ready', 'N/A')}"
        )
        agent_logger.info(f"  Pipeline Health: {health['score']}/100 ({health['status']})")
        if phase_failures:
            agent_logger.warning(f"  Phases with failures: {', '.join(phase_failures)}")
        agent_logger.info(f"  Phase Timings: [{timings_summary}]")
        agent_logger.info(f"  ZIP: {zip_archive_path}")
        agent_logger.info("==================================================")
        return report
