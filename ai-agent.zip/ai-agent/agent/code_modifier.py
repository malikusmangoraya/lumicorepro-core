import re
import os
from typing import Dict, Any, List
from utils.logger import agent_logger
from utils.file_manager import FileManager


class SecurityViolationError(Exception):
    """Raised when generated code violates security policies."""
    pass


class CodeModifier:
    """Modifies source code files safely with security validation and full-page generation."""

    DANGEROUS_PATTERNS = [
        r"\beval\s*\(",
        r"\bexec\s*\(",
        r"\bchild_process\b",
        r"\bsubprocess\b",
        r"\bos\.system\b",
        r"\bexecSync\b",
        r"\bspawnSync\b",
        r"\bshell_exec\b",
        r"\bprocess\.exit\b",
        r"\bfs\.unlink\b",
        r"\bfs\.rmdir\b",
        r"\bfs\.rmSync\b",
        r"\brmdirSync\b",
        r"__import__",
    ]

    def __init__(self, ai_provider=None):
        self.ai_provider = ai_provider

    async def generate_full_page(self, project_dir: str, spec: Dict[str, Any],
                                  template_info: Dict[str, Any], components: List[Dict[str, Any]],
                                  target_file: str = "frontend/src/pages/LandingPage.jsx") -> bool:
        """
        Generate a complete React page component by combining template structure,
        component imports, and AI-driven customisation based on spec and plan.
        """
        agent_logger.info(f"Generating full AI-driven page: {target_file}")
        if not self.ai_provider:
            agent_logger.warning("No AI provider available for page generation, using template.")
            return True

        prompt = self._build_page_generation_prompt(spec, template_info, components)
        try:
            new_content = self.ai_provider.generate_code(prompt)
            if new_content and len(new_content.strip()) > 50:
                violations = self.validate_code_security(new_content)
                if violations:
                    agent_logger.error(f"Security violations in page generation: {violations}")
                    raise SecurityViolationError("; ".join(violations))
                if self.validate_syntax_balance(new_content):
                    target_path = FileManager.resolve_safe_path(
                        os.path.join(project_dir, target_file), project_dir
                    )
                    os.makedirs(target_path.parent, exist_ok=True)
                    return FileManager.write_file(str(target_path), new_content, project_dir)
            return False
        except Exception as e:
            agent_logger.warning(f"AI page generation failed: {e}")
            return False

    def _build_page_generation_prompt(self, spec, template_info, components):
        """Build a prompt for generating a full React page from context."""
        wtype = spec.get("website_type", "ecommerce")
        features = spec.get("features", [])
        component_names = [c["name"] for c in components]
        return f"""
Generate a complete React functional component (JSX) for a {wtype} landing page.
Include imports, components, and TailwindCSS classes. Do NOT use external CSS files.
Features: {", ".join(features)}
Available components: {", ".join(component_names)}
Output ONLY the JSX code. Ensure proper import statements at the top.
        """.strip()


    @classmethod
    def validate_code_security(cls, code: str) -> List[str]:
        """Scan generated code for dangerous functions, execution primitives, and dangerous FS calls."""
        violations = []
        for pattern in cls.DANGEROUS_PATTERNS:
            if re.search(pattern, code):
                violations.append(f"Forbidden security pattern detected: '{pattern}'")
        return violations

    @classmethod
    def validate_syntax_balance(cls, code: str) -> bool:
        """Check for balanced braces, brackets, and parentheses in JS/JSX code snippets."""
        stack = []
        matching = {')': '(', '}': '{', ']': '['}
        in_string = False
        string_char = ''
        escaped = False

        for char in code:
            if escaped:
                escaped = False
                continue

            if char == '\\':
                escaped = True
                continue

            if in_string:
                if char == string_char:
                    in_string = False
                continue

            if char in ('"', "'", '`'):
                in_string = True
                string_char = char
                continue

            if char in ('(', '{', '['):
                stack.append(char)
            elif char in (')', '}', ']'):
                if not stack or stack[-1] != matching[char]:
                    return False
                stack.pop()

        return len(stack) == 0 and not in_string

    def update_imports(self, file_path: str, new_imports: List[str]) -> bool:
        """Inject new import statements cleanly into a React/JS file."""
        content = FileManager.read_file(file_path)
        if not content:
            return False

        existing_lines = content.split("\n")
        last_import_index = 0
        for idx, line in enumerate(existing_lines):
            if line.strip().startswith("import "):
                last_import_index = idx

        for imp in new_imports:
            if imp not in content:
                existing_lines.insert(last_import_index + 1, imp)
                last_import_index += 1

        updated_content = "\n".join(existing_lines)
        return FileManager.write_file(file_path, updated_content)

    def patch_file(self, file_path: str, instruction: str) -> bool:
        """Patch a file using AI provider if available, or append safe fallback code."""
        agent_logger.info(f"Patching file safely: {file_path}")
        content = FileManager.read_file(file_path)

        if self.ai_provider:
            try:
                new_content = self.ai_provider.modify_code(content, instruction)
                if new_content and len(new_content.strip()) > 10:
                    # Security Audit & Syntax Sanity Validation
                    violations = self.validate_code_security(new_content)
                    if violations:
                        agent_logger.error(f"Security violations in AI response for {file_path}: {violations}")
                        raise SecurityViolationError("; ".join(violations))

                    if not self.validate_syntax_balance(new_content):
                        agent_logger.warning(f"Syntax imbalance detected in generated JS for {file_path}. Falling back to original.")
                        return False

                    return FileManager.write_file(file_path, new_content)
            except Exception as e:
                agent_logger.warning(f"AI code modification failed or rejected: {e}. Applying safe patch.")

        # Safe fallback patch
        patched_content = content + f"\n\n// Added by LumicorePro AI Agent: {instruction}\n"
        return FileManager.write_file(file_path, patched_content)
