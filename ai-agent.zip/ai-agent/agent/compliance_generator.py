"""
Compliance Generator — LumicorePro AI Agent
============================================
Phase: International Delivery (Phase 11)

Generates legally-aware compliance artifacts for international markets:
  - GDPR (EU/UK)         → Cookie consent, Privacy Policy template, DPA checklist
  - CCPA (California US) → Do Not Sell, Data Subject Rights
  - PDPA (Thailand/SG)   → Personal Data Protection
  - POPIA (South Africa) → Protection of Personal Information
  - PIPEDA (Canada)      → Personal Information Protection
  - LGPD (Brazil)        → Lei Geral de Proteção de Dados
  - KVKK (Turkey)        → Kişisel Verileri Koruma Kanunu
  - PK Data Laws         → PECA 2016 / Pakistan data guidelines
  - MENA region          → Generic privacy template + Arabic localisation

Output:
  - COMPLIANCE.md          written to generated project root
  - privacy-policy.html    written to frontend/public/
  - cookie-config.js       written to frontend/src/config/
  - compliance_report dict returned to orchestrator
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
from utils.logger import agent_logger


class ComplianceGenerator:
    """Generates GDPR/CCPA/PDPA/regional compliance docs & code stubs."""

    # ── Regulation definitions ────────────────────────────────────────────
    REGULATIONS: Dict[str, Dict[str, Any]] = {
        "GDPR": {
            "full_name":    "General Data Protection Regulation",
            "jurisdictions":["EU", "EEA", "UK"],
            "regions":      ["EU"],
            "key_rights":   [
                "Right to access personal data",
                "Right to rectification",
                "Right to erasure (right to be forgotten)",
                "Right to restrict processing",
                "Right to data portability",
                "Right to object",
                "Rights related to automated decision-making",
            ],
            "requirements": [
                "Cookie consent banner with granular controls",
                "Privacy policy in local language",
                "Data Processing Agreement (DPA) with processors",
                "Data breach notification within 72 hours",
                "Lawful basis for processing (consent / legitimate interest)",
                "DPO appointment if processing at scale",
                "Records of processing activities (ROPA)",
            ],
            "penalty":      "Up to €20M or 4% of global annual turnover",
            "cookie_policy": "Opt-in required for non-essential cookies",
        },
        "CCPA": {
            "full_name":    "California Consumer Privacy Act",
            "jurisdictions":["California, USA"],
            "regions":      ["NA"],
            "key_rights":   [
                "Right to know about personal information collected",
                "Right to delete personal information",
                "Right to opt-out of sale of personal information",
                "Right to non-discrimination",
            ],
            "requirements": [
                '"Do Not Sell My Personal Information" link in footer',
                "Privacy policy updated annually",
                "Consumer request fulfillment within 45 days",
                "Opt-out mechanism for data sale",
            ],
            "penalty":      "$2,500–$7,500 per intentional violation",
            "cookie_policy": "Opt-out model (cookies allowed by default)",
        },
        "PDPA": {
            "full_name":    "Personal Data Protection Act",
            "jurisdictions":["Thailand", "Singapore"],
            "regions":      ["APAC"],
            "key_rights":   [
                "Right to access and correct data",
                "Right to withdraw consent",
                "Right to erasure",
                "Right to data portability",
            ],
            "requirements": [
                "Explicit consent before collecting personal data",
                "Data retention policy must be defined",
                "Cross-border transfer restrictions",
                "Appointment of Data Protection Officer (DPO)",
            ],
            "penalty":      "Up to THB 5M / SGD 1M per violation",
            "cookie_policy": "Opt-in required",
        },
        "POPIA": {
            "full_name":    "Protection of Personal Information Act",
            "jurisdictions":["South Africa"],
            "regions":      ["AF"],
            "key_rights":   [
                "Right to be notified",
                "Right to access",
                "Right to correction or deletion",
                "Right to object to processing",
            ],
            "requirements": [
                "Information Officer registration with regulator",
                "PAIA manual must be available",
                "Breach notification within reasonable time",
                "Data minimisation principle",
            ],
            "penalty":      "Up to ZAR 10M or 10 years imprisonment",
            "cookie_policy": "Opt-in required",
        },
        "LGPD": {
            "full_name":    "Lei Geral de Proteção de Dados",
            "jurisdictions":["Brazil"],
            "regions":      ["LATAM"],
            "key_rights":   [
                "Right to confirmation",
                "Right to access",
                "Right to correction",
                "Right to anonymisation or deletion",
                "Right to portability",
                "Right to information about third parties",
                "Right to revoke consent",
            ],
            "requirements": [
                "Explicit purpose for data collection",
                "DPO (Encarregado) must be appointed",
                "Privacy policy in Portuguese",
                "Security incident reporting",
            ],
            "penalty":      "Up to 2% of revenue in Brazil (max R$50M)",
            "cookie_policy": "Opt-in required",
        },
        "PIPEDA": {
            "full_name":    "Personal Information Protection and Electronic Documents Act",
            "jurisdictions":["Canada"],
            "regions":      ["NA"],
            "key_rights":   [
                "Right to access personal information",
                "Right to challenge compliance",
                "Right to withdraw consent",
            ],
            "requirements": [
                "Privacy policy must be publicly available",
                "Accountability principle — designate a privacy officer",
                "Breach of security safeguards reporting",
            ],
            "penalty":      "Up to CAD $100,000",
            "cookie_policy": "Opt-in for sensitive data; opt-out for general",
        },
        "PECA_PK": {
            "full_name":    "Prevention of Electronic Crimes Act (Pakistan)",
            "jurisdictions":["Pakistan"],
            "regions":      ["SA"],
            "key_rights":   [
                "Protection of identity",
                "Protection from data breach",
            ],
            "requirements": [
                "No unauthorised interception of data",
                "Privacy policy in Urdu or English",
                "Data stored on servers accessible to PTA if required",
                "Cyber crime reporting mechanism",
            ],
            "penalty":      "Up to PKR 5M and/or 3 years imprisonment",
            "cookie_policy": "Recommended opt-in",
        },
        "KVKK": {
            "full_name":    "Kişisel Verileri Koruma Kanunu (Turkey)",
            "jurisdictions":["Turkey"],
            "regions":      ["MENA"],
            "key_rights":   [
                "Right to learn whether personal data is processed",
                "Right to access",
                "Right to demand correction",
                "Right to demand deletion",
                "Right to object",
            ],
            "requirements": [
                "Registration with VERBIS system",
                "Explicit consent for special categories",
                "Privacy notice in Turkish",
                "Data breach notification within reasonable time",
            ],
            "penalty":      "Up to TRY 1.8M",
            "cookie_policy": "Opt-in required",
        },
    }

    # ── Region → applicable regulations ──────────────────────────────────
    REGION_REGS: Dict[str, List[str]] = {
        "EU":    ["GDPR"],
        "NA":    ["CCPA", "PIPEDA"],
        "SA":    ["PECA_PK"],
        "MENA":  ["KVKK"],
        "APAC":  ["PDPA"],
        "AF":    ["POPIA"],
        "LATAM": ["LGPD"],
    }

    def generate(self, spec: Dict[str, Any], project_dir: str, region: str = "NA") -> Dict[str, Any]:
        """Generate all compliance artifacts for the given project and region."""
        agent_logger.info(f"ComplianceGenerator: Generating compliance for region={region}...")

        applicable = self._get_applicable_regs(region, spec)
        artifacts = []

        # 1. COMPLIANCE.md in project root
        md_path = os.path.join(project_dir, "COMPLIANCE.md")
        md_content = self._build_compliance_md(applicable, spec, region)
        self._write_file(md_path, md_content)
        artifacts.append(md_path)

        # 2. Privacy Policy HTML
        pp_dir = os.path.join(project_dir, "frontend", "public")
        os.makedirs(pp_dir, exist_ok=True)
        pp_path = os.path.join(pp_dir, "privacy-policy.html")
        pp_content = self._build_privacy_policy(applicable, spec, region)
        self._write_file(pp_path, pp_content)
        artifacts.append(pp_path)

        # 3. Cookie Config JS
        cfg_dir = os.path.join(project_dir, "frontend", "src", "config")
        os.makedirs(cfg_dir, exist_ok=True)
        cookie_path = os.path.join(cfg_dir, "cookie-config.js")
        cookie_content = self._build_cookie_config(applicable, region)
        self._write_file(cookie_path, cookie_content)
        artifacts.append(cookie_path)

        report = {
            "region":              region,
            "applicable_regs":     [r["full_name"] for r in applicable],
            "reg_codes":           [r["code"] for r in applicable],
            "artifacts_generated": artifacts,
            "cookie_policy_model": self._get_cookie_model(applicable),
            "requires_dpo":        any(
                "DPO" in req or "Data Protection Officer" in req
                for r in applicable for req in r["requirements"]
            ),
            "requires_consent_banner": any(
                r.get("cookie_policy", "").startswith("Opt-in")
                for r in applicable
            ),
            "penalties":           {r["code"]: r["penalty"] for r in applicable},
        }

        agent_logger.info(
            f"ComplianceGenerator: {len(applicable)} regulations, "
            f"{len(artifacts)} artifacts written."
        )
        return report

    # ── Internal helpers ──────────────────────────────────────────────────
    def _get_applicable_regs(self, region: str, spec: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Return regulation dicts applicable to the region."""
        codes = self.REGION_REGS.get(region, ["GDPR"])  # default to strictest
        result = []
        for code in codes:
            if code in self.REGULATIONS:
                entry = {"code": code, **self.REGULATIONS[code]}
                result.append(entry)
        # If international/SaaS — add GDPR as baseline regardless
        if "GDPR" not in codes and spec.get("website_type") in ("saas", "dashboard", "fintech"):
            result.append({"code": "GDPR", **self.REGULATIONS["GDPR"]})
        return result

    def _get_cookie_model(self, applicable: List[Dict]) -> str:
        """Strictest cookie model across applicable regulations."""
        if any(r.get("cookie_policy", "").startswith("Opt-in") for r in applicable):
            return "opt-in"
        return "opt-out"

    def _write_file(self, path: str, content: str) -> None:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
        except Exception as e:
            agent_logger.warning(f"ComplianceGenerator: Could not write {path}: {e}")

    def _build_compliance_md(self, applicable: List[Dict], spec: Dict, region: str) -> str:
        project = spec.get("project_name", "Your Project")
        date = datetime.utcnow().strftime("%Y-%m-%d")
        lines = [
            f"# Compliance Report — {project}",
            f"\nGenerated: {date} | Region: {region} | LumicorePro AI Agent",
            "\n---\n",
            "## Applicable Regulations\n",
        ]
        for reg in applicable:
            lines.append(f"### {reg['full_name']} ({reg['code']})")
            lines.append(f"**Jurisdictions:** {', '.join(reg['jurisdictions'])}")
            lines.append(f"**Cookie Policy:** {reg.get('cookie_policy', 'N/A')}")
            lines.append(f"**Penalty:** {reg.get('penalty', 'N/A')}\n")
            lines.append("**Key User Rights:**")
            for right in reg["key_rights"]:
                lines.append(f"  - {right}")
            lines.append("\n**Implementation Requirements:**")
            for req in reg["requirements"]:
                lines.append(f"  - [ ] {req}")
            lines.append("")

        lines += [
            "---\n",
            "## Action Checklist\n",
            "- [ ] Add Cookie Consent Banner (see `frontend/src/components/common/CookieConsent.jsx`)",
            "- [ ] Link Privacy Policy in footer",
            "- [ ] Add 'Contact DPO / Privacy Officer' email to footer",
            "- [ ] Enable HTTPS (TLS 1.2+) in production",
            "- [ ] Implement data deletion endpoint `DELETE /api/users/:id`",
            "- [ ] Add rate limiting to all auth endpoints",
            "- [ ] Log all data access for audit trail",
            "\n---\n",
            "> ⚠️ **Disclaimer:** This document is AI-generated for informational purposes.",
            "> Always consult a qualified legal professional before deployment.",
        ]
        return "\n".join(lines)

    def _build_privacy_policy(self, applicable: List[Dict], spec: Dict, region: str) -> str:
        project = spec.get("project_name", "Our Platform")
        regs = ", ".join(r["full_name"] for r in applicable)
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Privacy Policy — {project}</title>
  <style>
    body {{ font-family: system-ui, sans-serif; max-width: 800px; margin: 40px auto; padding: 0 20px; line-height: 1.6; color: #1a1a1a; }}
    h1 {{ color: #0d9488; }} h2 {{ color: #334155; margin-top: 2rem; }}
    a {{ color: #0d9488; }} footer {{ margin-top: 3rem; color: #64748b; font-size: 0.875rem; }}
  </style>
</head>
<body>
  <h1>Privacy Policy</h1>
  <p><strong>Last Updated:</strong> {datetime.utcnow().strftime("%B %d, %Y")}</p>
  <p>This Privacy Policy explains how <strong>{project}</strong> collects, uses, and protects your personal information.
     This policy is compliant with: <em>{regs}</em>.</p>

  <h2>1. Information We Collect</h2>
  <ul>
    <li>Account information (name, email, password hash)</li>
    <li>Transaction data (order history, payment method type — not card numbers)</li>
    <li>Usage data (pages visited, actions taken) via cookies and analytics</li>
    <li>Device information (IP address, browser type, operating system)</li>
  </ul>

  <h2>2. How We Use Your Information</h2>
  <ul>
    <li>To provide and improve our services</li>
    <li>To process transactions and send related notifications</li>
    <li>To comply with legal obligations</li>
    <li>To send marketing communications (only with your explicit consent)</li>
  </ul>

  <h2>3. Your Rights</h2>
  <p>Depending on your location, you may have the right to:</p>
  <ul>
    <li>Access the personal data we hold about you</li>
    <li>Request correction or deletion of your data</li>
    <li>Object to or restrict processing</li>
    <li>Data portability (receive your data in a machine-readable format)</li>
    <li>Withdraw consent at any time</li>
  </ul>

  <h2>4. Cookies</h2>
  <p>We use cookies to enhance your experience. You can manage cookie preferences via our Cookie Settings panel.
     Essential cookies are required for the site to function; analytics and marketing cookies require your consent.</p>

  <h2>5. Data Retention</h2>
  <p>We retain personal data for as long as necessary to provide our services and comply with legal obligations.
     Account data is retained for 3 years after account closure unless deletion is requested.</p>

  <h2>6. Third-Party Sharing</h2>
  <p>We do not sell your personal data. We may share data with trusted service providers
     (payment processors, cloud hosting, analytics) under strict data processing agreements.</p>

  <h2>7. International Transfers</h2>
  <p>Your data may be processed in countries outside your own. We ensure adequate protection
     through Standard Contractual Clauses (SCCs) or equivalent mechanisms.</p>

  <h2>8. Contact Us</h2>
  <p>For privacy-related requests, contact our Data Protection Officer at:
     <a href="mailto:privacy@{project.lower().replace(' ', '')}.com">
       privacy@{project.lower().replace(' ', '')}.com
     </a>
  </p>

  <footer>
    <p>© {datetime.utcnow().year} {project}. Generated by LumicorePro AI Agent.</p>
    <p>⚠️ This is a template. Review with a qualified legal professional before publishing.</p>
  </footer>
</body>
</html>"""

    def _build_cookie_config(self, applicable: List[Dict], region: str) -> str:
        model = self._get_cookie_model(applicable)
        opt_in = "true" if model == "opt-in" else "false"
        reg_codes = [r["code"] for r in applicable]
        return f"""/**
 * Cookie Configuration — LumicorePro
 * Region: {region} | Regulations: {', '.join(reg_codes)}
 * Model: {model.upper()} — {"Consent required before non-essential cookies" if model == "opt-in" else "Opt-out model — cookies active by default"}
 */

export const COOKIE_CONFIG = {{
  // Consent model
  requireConsent: {opt_in},          // true = GDPR/opt-in, false = CCPA/opt-out
  region: '{region}',
  regulations: {reg_codes},

  // Cookie categories
  categories: {{
    essential: {{
      id: 'essential',
      name: 'Essential Cookies',
      description: 'Required for the website to function. Cannot be disabled.',
      required: true,
      defaultEnabled: true,
    }},
    analytics: {{
      id: 'analytics',
      name: 'Analytics Cookies',
      description: 'Help us understand how visitors use our website (e.g. Google Analytics).',
      required: false,
      defaultEnabled: {'false' if opt_in == 'true' else 'true'},
    }},
    marketing: {{
      id: 'marketing',
      name: 'Marketing Cookies',
      description: 'Used to show you relevant advertising and track ad performance.',
      required: false,
      defaultEnabled: false,
    }},
    preferences: {{
      id: 'preferences',
      name: 'Preference Cookies',
      description: 'Remember your settings like language and currency.',
      required: false,
      defaultEnabled: true,
    }},
  }},

  // Storage
  consentCookieName: 'lumicore_consent',
  consentCookieExpiry: 365,           // days

  // UI
  showBanner: {opt_in},
  position: 'bottom',                 // 'bottom' | 'top' | 'modal'
  privacyPolicyUrl: '/privacy-policy',
  cookiePolicyUrl: '/cookie-policy',
}};

/**
 * Check if a cookie category is consented
 * Usage: if (hasConsent('analytics')) {{ loadGA(); }}
 */
export function hasConsent(category) {{
  try {{
    const stored = JSON.parse(localStorage.getItem(COOKIE_CONFIG.consentCookieName) || '{{}}');
    if (COOKIE_CONFIG.categories[category]?.required) return true;
    return stored[category] ?? COOKIE_CONFIG.categories[category]?.defaultEnabled ?? false;
  }} catch {{
    return false;
  }}
}}

/**
 * Save consent choices
 * Usage: saveConsent({{ analytics: true, marketing: false, preferences: true }})
 */
export function saveConsent(choices) {{
  const consent = {{
    essential: true,
    timestamp: new Date().toISOString(),
    ...choices,
  }};
  localStorage.setItem(COOKIE_CONFIG.consentCookieName, JSON.stringify(consent));
  window.dispatchEvent(new CustomEvent('cookieConsentUpdated', {{ detail: consent }}));
}}
"""
