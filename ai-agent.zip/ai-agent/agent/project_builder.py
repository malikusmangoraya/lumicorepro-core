import os
import re
import json
from pathlib import Path
from typing import Dict, Any, List, Set, Optional
from config.settings import PROJECT_ROOT, GENERATED_PROJECTS_DIR
from utils.logger import agent_logger
from utils.file_manager import FileManager

class ProjectBuilder:
    """Assembles template, components, assets, backend, and database schema into a generated project with NPM auto-fixing & design system injection."""

    # Template path mapping: registry "file_path" -> actual project directory
    TEMPLATE_PATH_MAP = {
        # Business
        "src/templates/business/corporate-template-01": "src/templates/business/corporate-template-01",
        # E-commerce
        "src/templates/ecommerce/electronics/electronics-template-01": "src/templates/ecommerce/electronics/electronics-template-01",
        "src/templates/ecommerce/electronics/electronics-template-02": "src/templates/ecommerce/electronics/electronics-template-02",
        "src/templates/ecommerce/electronics/electronics-template-03": "src/templates/ecommerce/electronics/electronics-template-03",
        # Real estate
        "src/templates/realestate/property-template-01": "src/templates/realestate/property-template-01",
        # Restaurant
        "src/templates/restaurant/cafe-template-01": "src/templates/restaurant/cafe-template-01",
        # Portfolio
        "src/templates/portfolio/personal-template-01": "src/templates/portfolio/personal-template-01",
        # Education
        "src/templates/education/lms-template-01": "src/templates/education/lms-template-01",
        # Healthcare
        "src/templates/healthcare/medical-template-01": "src/templates/healthcare/medical-template-01",
        # Fitness
        "src/templates/fitness/gym-template-01": "src/templates/fitness/gym-template-01",
        # Travel
        "src/templates/travel/agency-template-01": "src/templates/travel/agency-template-01",
        # Creative
        "src/templates/creative/studio-template-01": "src/templates/creative/studio-template-01",
    }

    # Fallback template per category (first available in that category)
    CATEGORY_FALLBACK_TEMPLATES = {
        "business": "src/templates/business/corporate-template-01",
        "ecommerce": "src/templates/ecommerce/electronics/electronics-template-01",
        "realestate": "src/templates/realestate/property-template-01",
        "restaurant": "src/templates/restaurant/cafe-template-01",
        "portfolio": "src/templates/portfolio/personal-template-01",
        "education": "src/templates/education/lms-template-01",
        "healthcare": "src/templates/healthcare/medical-template-01",
        "fitness": "src/templates/fitness/gym-template-01",
        "travel": "src/templates/travel/agency-template-01",
        "creative": "src/templates/creative/studio-template-01",
        "saas": "src/templates/business/corporate-template-01",
        "dashboard": "src/templates/business/corporate-template-01",
        "fintech": "src/templates/business/corporate-template-01",
        "social": "src/templates/business/corporate-template-01",
        "fashion": "src/templates/ecommerce/electronics/electronics-template-01",
    }

    PACKAGE_VERSION_MAP = {
        "react": "^18.2.0",
        "react-dom": "^18.2.0",
        "react-router-dom": "^6.22.0",
        "lucide-react": "^0.344.0",
        "framer-motion": "^11.0.0",
        "recharts": "^2.12.0",
        "axios": "^1.6.7",
        "tailwindcss": "^3.4.1",
        "autoprefixer": "^10.4.18",
        "postcss": "^8.4.35",
        "express": "^4.19.2",
        "cors": "^2.8.5",
        "dotenv": "^16.4.5",
        "pg": "^8.11.5",
        "jsonwebtoken": "^9.0.2",
        "bcryptjs": "^2.4.3",
        "express-validator": "^7.0.1"
    }

    def _resolve_template_path(self, template_info: Dict[str, Any]) -> Path:
        """Resolve template directory path using mapping, with fallback logic."""
        rel_path = template_info.get("file_path", "") if template_info else ""
        # Use the mapping if available, otherwise use rel_path directly
        mapped = self.TEMPLATE_PATH_MAP.get(rel_path, rel_path)
        resolved = (PROJECT_ROOT / mapped).resolve()
        if resolved.exists():
            return resolved
        # Try mapping without the "src/templates/" prefix
        alt_path = "src/templates/" + rel_path.replace("src/templates/", "")
        alt_resolved = (PROJECT_ROOT / alt_path).resolve()
        if alt_resolved.exists():
            return alt_resolved
        # Try every known template path as fallback
        for known in self.TEMPLATE_PATH_MAP.values():
            candidate = (PROJECT_ROOT / known).resolve()
            if candidate.exists():
                agent_logger.warning(f"Template {rel_path} not found, falling back to {known}")
                return candidate
        return resolved  # Return original even if not found

    def build_project(self, plan: Dict[str, Any]) -> str:
        """Execute assembly plan and return path of generated project."""
        project_name = self._safe_project_name(plan.get("project_name", "generated-app"))
        plan["project_name"] = project_name
        target_dir = (GENERATED_PROJECTS_DIR / project_name).resolve()
        target_dir.relative_to(GENERATED_PROJECTS_DIR)
        agent_logger.info(f"Building project '{project_name}' at: {target_dir}")

        FileManager.ensure_dir(str(target_dir), str(GENERATED_PROJECTS_DIR))
        frontend_dir = target_dir / "frontend"
        backend_dir = target_dir / "backend"
        database_dir = target_dir / "database"

        # 1. Copy Frontend Template
        template_info = plan.get("template", {})
        template_src = self._resolve_template_path(template_info)

        if template_src.exists():
            agent_logger.info(f"Copying frontend template from: {template_src}")
            FileManager.copy_directory(str(template_src), str(frontend_dir), ignore_patterns=["node_modules", "dist", ".git"])
        else:
            agent_logger.warning(f"Template path {template_src} not found. Creating default scaffold.")
            FileManager.ensure_dir(str(frontend_dir / "src"))
            # Create default package.json & App.jsx
            default_pkg = {
                "name": project_name,
                "private": True,
                "version": "1.0.0",
                "type": "module",
                "dependencies": {"react": "^18.2.0", "react-dom": "^18.2.0", "lucide-react": "^0.344.0"}
            }
            FileManager.write_json(str(frontend_dir / "package.json"), default_pkg)
            default_app = """import React from 'react';\n\nexport function App() {\n  return (\n    <div className="min-h-screen bg-slate-950 text-white p-8">\n      <h1 className="text-3xl font-bold">Generated Project</h1>\n    </div>\n  );\n}\nexport default App;\n"""
            FileManager.write_file(str(frontend_dir / "src" / "App.jsx"), default_app)


        # 2. Copy Selected Components into frontend/src/components/
        components = plan.get("components", [])
        copied_components = []
        for comp in components:
            comp_rel = comp.get("file_path")
            if comp_rel:
                comp_src = (PROJECT_ROOT / comp_rel).resolve()
                if comp_src.exists():
                    rel_to_components = os.path.relpath(str(comp_src), str(PROJECT_ROOT / "src" / "components"))
                    comp_dst = frontend_dir / "src" / "components" / rel_to_components
                    agent_logger.info(f"Copying component '{comp['name']}' to: {comp_dst}")
                    FileManager.copy_file(str(comp_src), str(comp_dst))
                    copied_components.append((comp['name'], rel_to_components))
                else:
                    # Check in the template's own components directory
                    template_comp_dirs = [
                        frontend_dir / "src" / "components",
                        frontend_dir / "src" / "components" / comp.get("category", ""),
                    ]
                    found = False
                    for tcd in template_comp_dirs:
                        candidate = tcd / comp_rel.split("/")[-1]
                        if candidate.exists():
                            rel = str(candidate.relative_to(frontend_dir / "src" / "components"))
                            copied_components.append((comp['name'], rel.replace("\\", "/").replace(".jsx", "").replace(".js", "")))
                            found = True
                            break
                    if not found:
                        agent_logger.warning(f"Component '{comp['name']}' not found at {comp_src}. Will be noted for AI generation.")
                        # Register it anyway so the barrel knows about it
                        copied_components.append((comp['name'], comp_rel.split("/")[-1].replace(".jsx", "").replace(".js", "")))

        # 3. Generate Component Barrel Index File (frontend/src/components/index.js)
        self._generate_component_barrel(frontend_dir, copied_components)

        # 4. Copy Selected Assets into frontend/src/assets/
        assets = plan.get("assets", {})
        for image_item in assets.get("images", []):
            img_rel = image_item.get("file_path")
            if img_rel:
                img_src = (PROJECT_ROOT / img_rel).resolve()
                if img_src.exists():
                    img_dst = frontend_dir / "src" / "assets" / "images" / img_src.name
                    FileManager.copy_file(str(img_src), str(img_dst))

        # 5. Inject Premium Design System Styles & Tailwind Config
        self._inject_design_system_styles(frontend_dir)

        # 6. Copy Backend Base into backend/
        backend_info = plan.get("backend", {})
        backend_rel_path = backend_info.get("file_path", "backend-library/ecommerce-base")
        backend_src = (PROJECT_ROOT / backend_rel_path).resolve()

        if backend_src.exists():
            agent_logger.info(f"Copying backend base from: {backend_src}")
            FileManager.copy_directory(str(backend_src), str(backend_dir), ignore_patterns=["node_modules", ".git"])

        # 7. Consolidate Database Schemas into database/schema.sql
        FileManager.ensure_dir(str(database_dir))
        merged_sql = "-- LumicorePro Core Generated Database Schema\n\n"
        schemas = plan.get("database_schemas", [])

        for s in schemas:
            s_rel = s.get("file_path")
            if s_rel:
                s_src = (PROJECT_ROOT / s_rel).resolve()
                if s_src.exists():
                    merged_sql += f"-- Schema: {s.get('name')}\n"
                    merged_sql += FileManager.read_file(str(s_src)) + "\n\n"

        schema_dst = database_dir / "schema.sql"
        FileManager.write_file(str(schema_dst), merged_sql)

        # 8. Auto-Fix Missing NPM Dependencies in package.json files
        self._auto_fix_npm_dependencies(frontend_dir, is_backend=False)
        self._auto_fix_npm_dependencies(backend_dir, is_backend=True)

        # 9. Generate Root README.md & .env.example
        self._generate_project_meta(target_dir, plan)

        agent_logger.info(f"Successfully assembled project '{project_name}'!")
        return str(target_dir)

    @staticmethod
    def _safe_project_name(project_name: Any) -> str:
        """Convert user-derived names into stable, filesystem-safe project slugs."""
        value = re.sub(r"[^a-zA-Z0-9]+", "-", str(project_name or "generated-app")).strip("-").lower()
        return value[:80] or "generated-app"

    def _generate_component_barrel(self, frontend_dir: Path, copied_components: List[tuple]) -> None:
        """Generate frontend/src/components/index.js barrel exporter."""
        barrel_path = frontend_dir / "src" / "components" / "index.js"
        lines = ["// LumicorePro Core Generated Component Barrel Exporter\n"]
        for cname, rel_path in copied_components:
            clean_rel = rel_path.replace("\\", "/").replace(".jsx", "").replace(".js", "")
            lines.append(f"export {{ default as {cname} }} from './{clean_rel}';")
        FileManager.write_file(str(barrel_path), "\n".join(lines) + "\n")

    def _inject_design_system_styles(self, frontend_dir: Path) -> None:
        """Inject Glassmorphism, Dark Slate theme CSS, and Tailwind config into frontend."""
        css_content = """@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  body {
    @apply bg-slate-950 text-slate-100 font-sans antialiased selection:bg-cyan-500 selection:text-slate-950;
  }
}

@layer utilities {
  .glass-panel {
    @apply bg-slate-900/70 backdrop-blur-md border border-slate-800 shadow-xl;
  }
  .glass-card {
    @apply bg-slate-900/60 backdrop-blur border border-slate-800/80 hover:border-cyan-500/50 transition-all duration-300;
  }
  .gradient-text {
    @apply bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500 bg-clip-text text-transparent;
  }
}

/* Smooth custom scrollbars */
::-webkit-scrollbar {
  width: 8px;
}
::-webkit-scrollbar-track {
  background: #090d16;
}
::-webkit-scrollbar-thumb {
  background: #1e293b;
  border-radius: 4px;
}
::-webkit-scrollbar-thumb:hover {
  background: #06b6d4;
}
"""
        FileManager.write_file(str(frontend_dir / "src" / "index.css"), css_content)

    def _auto_fix_npm_dependencies(self, project_sub_dir: Path, is_backend: bool = False) -> None:
        """Scan source files and auto-inject missing NPM packages into package.json."""
        pkg_file = project_sub_dir / "package.json"
        if not pkg_file.exists():
            return

        pkg_data = FileManager.read_json(str(pkg_file))
        deps = pkg_data.get("dependencies", {})
        dev_deps = pkg_data.get("devDependencies", {})
        all_declared = set(deps.keys()).union(set(dev_deps.keys()))

        detected_imports = set()
        for root, _, files in os.walk(project_sub_dir):
            if "node_modules" in root or "dist" in root:
                continue
            for fname in files:
                if fname.endswith((".js", ".jsx", ".ts", ".tsx")):
                    content = FileManager.read_file(os.path.join(root, fname))
                    if is_backend:
                        found = re.findall(r"require\(['\"]([^'\".\/][^'\"]*)['\"]\)", content)
                    else:
                        found = re.findall(r"import\s+.*?\s+from\s+['\"]([^'\".\/][^'\"]*)['\"]", content)

                    for imp in found:
                        pkg_name = imp.split('/')[0] if not imp.startswith('@') else '/'.join(imp.split('/')[:2])
                        if pkg_name not in ["fs", "path", "http", "https", "events", "util", "crypto", "os", "stream", "react", "react-dom"]:
                            detected_imports.add(pkg_name)

        modified = False
        for pkg in detected_imports:
            if pkg not in all_declared:
                version = self.PACKAGE_VERSION_MAP.get(pkg, "^1.0.0")
                agent_logger.info(f"Auto-fixing missing NPM dependency '{pkg}': {version} in {pkg_file.name}")
                deps[pkg] = version
                modified = True

        if modified:
            pkg_data["dependencies"] = deps
            FileManager.write_json(str(pkg_file), pkg_data)

    def _generate_project_meta(self, target_dir: Path, plan: Dict[str, Any]) -> None:
        pname = plan.get("project_name")
        readme_content = f"""# {pname.upper()}

Generated automatically by **LumicorePro Core AI Agent**.

## Stack
- **Frontend**: React.js + Vite + Tailwind CSS
- **Backend**: Node.js + Express.js
- **Database**: PostgreSQL

See `INSTRUCTIONS.md` for complete installation, database migration, and deployment instructions.
"""
        FileManager.write_file(str(target_dir / "README.md"), readme_content)
        
        env_content = """# Environment Config
PORT=5000
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/lumicore_db
# Generate a unique secret before production deployment.
JWT_SECRET=replace_with_a_random_64_character_secret
"""
        FileManager.write_file(str(target_dir / "frontend" / ".env.example"), env_content)
        FileManager.write_file(str(target_dir / "backend" / ".env.example"), env_content)
        self._generate_instructions_guide(target_dir, plan)
        self._generate_docker_setup(target_dir, plan)
        self._generate_seo_files(target_dir, plan)
        self._generate_cicd_workflow(target_dir, plan)
        self._generate_deployment_checklist(target_dir, plan)

    def _generate_docker_setup(self, target_dir: Path, plan: Dict[str, Any]) -> None:
        """Generate Dockerfile + docker-compose.yml for full-stack Docker deployment."""
        pname = plan.get("project_name", "app")
        db_name = pname.replace("-", "_").replace(" ", "_") + "_db"

        # Frontend Dockerfile
        frontend_dockerfile = """\
# ── Stage 1: Build ─────────────────────────────────
FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production=false
COPY . .
RUN npm run build

# ── Stage 2: Serve with Nginx ───────────────────────
FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
"""

        nginx_conf = """\
server {
    listen 80;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    # SPA fallback
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache static assets
    location ~* \\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
"""

        # Backend Dockerfile
        backend_dockerfile = """\
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN addgroup -S appgroup && adduser -S appuser -G appgroup
USER appuser
EXPOSE 5000
HEALTHCHECK --interval=30s --timeout=10s --retries=3 \\
  CMD wget -qO- http://localhost:5000/health || exit 1
CMD ["node", "server.js"]
"""

        # docker-compose.yml
        docker_compose = f"""\
version: "3.9"

services:
  # ── PostgreSQL Database ─────────────────────────────────────
  db:
    image: postgres:16-alpine
    container_name: {pname}-db
    restart: unless-stopped
    environment:
      POSTGRES_DB: {db_name}
      POSTGRES_USER: ${{POSTGRES_USER:-postgres}}
      POSTGRES_PASSWORD: ${{POSTGRES_PASSWORD:-changeme}}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database/schema.sql:/docker-entrypoint-initdb.d/01-schema.sql:ro
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${{POSTGRES_USER:-postgres}}"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - {pname}-network

  # ── Backend API ─────────────────────────────────────────────
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: {pname}-api
    restart: unless-stopped
    depends_on:
      db:
        condition: service_healthy
    environment:
      NODE_ENV: production
      PORT: 5000
      DATABASE_URL: postgresql://${{POSTGRES_USER:-postgres}}:${{POSTGRES_PASSWORD:-changeme}}@db:5432/{db_name}
      JWT_SECRET: ${{JWT_SECRET:-change_this_secret_in_production}}
      CORS_ORIGIN: ${{CORS_ORIGIN:-http://localhost}}
    ports:
      - "5000:5000"
    networks:
      - {pname}-network
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:5000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # ── Frontend (Nginx) ────────────────────────────────────────
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: {pname}-web
    restart: unless-stopped
    depends_on:
      - backend
    ports:
      - "80:80"
      - "443:443"
    networks:
      - {pname}-network

volumes:
  postgres_data:
    name: {pname}-postgres-data

networks:
  {pname}-network:
    driver: bridge
"""

        # .dockerignore
        dockerignore = """\
node_modules
dist
.git
.env
*.log
coverage
.DS_Store
"""

        # Write files
        FileManager.write_file(str(target_dir / "frontend" / "Dockerfile"),   frontend_dockerfile)
        FileManager.write_file(str(target_dir / "frontend" / "nginx.conf"),    nginx_conf)
        FileManager.write_file(str(target_dir / "backend"  / "Dockerfile"),   backend_dockerfile)
        FileManager.write_file(str(target_dir / "docker-compose.yml"),         docker_compose)
        FileManager.write_file(str(target_dir / "frontend" / ".dockerignore"), dockerignore)
        FileManager.write_file(str(target_dir / "backend"  / ".dockerignore"), dockerignore)
        agent_logger.info("Docker setup generated: Dockerfile (frontend+backend), docker-compose.yml, nginx.conf")

    def _generate_seo_files(self, target_dir: Path, plan: Dict[str, Any]) -> None:
        """Generate sitemap.xml, robots.txt, JSON-LD structured data, and meta tags file."""
        pname      = plan.get("project_name", "website")
        spec       = plan.get("spec", {}) or {}
        wtype      = spec.get("website_type", "business")
        industry   = spec.get("industry", "general")
        features   = spec.get("features", [])
        base_url   = f"https://www.{pname.replace('_', '-')}.com"

        # robots.txt
        robots = f"""\
User-agent: *
Allow: /

# Disallow admin and auth pages from indexing
Disallow: /admin/
Disallow: /api/
Disallow: /dashboard/
Disallow: /login
Disallow: /register
Disallow: /_next/static/

# Sitemap location
Sitemap: {base_url}/sitemap.xml

# Crawl delay for polite bots
Crawl-delay: 1
"""

        # sitemap.xml
        now_date = "2026-01-01"
        pages = [
            ("", "1.0", "daily"),
            ("about", "0.8", "monthly"),
            ("contact", "0.7", "monthly"),
            ("services", "0.9", "weekly"),
            ("pricing", "0.9", "weekly"),
        ]
        if wtype in ("ecommerce",):
            pages += [("products", "1.0", "daily"), ("cart", "0.6", "weekly")]
        if wtype in ("blog", "media"):
            pages += [("blog", "1.0", "daily"), ("categories", "0.8", "weekly")]
        if "doctor_search" in features:
            pages += [("doctors", "1.0", "daily"), ("appointments", "0.9", "weekly")]

        url_entries = "\n".join([
            f"""  <url>
    <loc>{base_url}/{p[0]}</loc>
    <lastmod>{now_date}</lastmod>
    <changefreq>{p[2]}</changefreq>
    <priority>{p[1]}</priority>
  </url>""" for p in pages
        ])
        sitemap = f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
{url_entries}
</urlset>
"""

        # JSON-LD Structured Data
        schema_type = {
            "restaurant":  "Restaurant",
            "healthcare":  "MedicalBusiness",
            "ecommerce":   "Store",
            "education":   "EducationalOrganization",
            "lawfirm":     "LegalService",
            "nonprofit":   "NGO",
            "fitness":     "SportsActivityLocation",
            "creative":    "ProfessionalService",
        }.get(wtype, "Organization")

        json_ld = f"""{{
  "@context": "https://schema.org",
  "@type": "{schema_type}",
  "name": "{pname.replace('-', ' ').title()}",
  "url": "{base_url}",
  "description": "Professional {industry} {wtype} powered by LumicorePro.",
  "foundingDate": "2026",
  "contactPoint": {{
    "@type": "ContactPoint",
    "contactType": "customer service",
    "availableLanguage": ["English", "Urdu"]
  }},
  "sameAs": [
    "https://www.facebook.com/{pname}",
    "https://www.instagram.com/{pname}",
    "https://twitter.com/{pname}"
  ]
}}
"""

        # Meta tags reference file (for developer)
        meta_tags_md = f"""# SEO Meta Tags Reference — {pname}

## Essential Meta Tags (add to index.html <head>)

```html
<!-- Primary Meta Tags -->
<title>{pname.replace('-', ' ').title()} — Premium {industry.title()} Platform</title>
<meta name="title" content="{pname.replace('-', ' ').title()} — Premium {industry.title()} Platform" />
<meta name="description" content="Professional {industry} {wtype} with modern UI, fast performance, and international standards." />
<meta name="keywords" content="{industry}, {wtype}, online, professional, premium" />
<meta name="robots" content="index, follow" />
<meta name="language" content="English" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="canonical" href="{base_url}" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="{base_url}" />
<meta property="og:title" content="{pname.replace('-', ' ').title()}" />
<meta property="og:description" content="Professional {industry} platform with modern design." />
<meta property="og:image" content="{base_url}/og-image.jpg" />

<!-- Twitter Card -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:url" content="{base_url}" />
<meta property="twitter:title" content="{pname.replace('-', ' ').title()}" />
<meta property="twitter:description" content="Professional {industry} platform." />
<meta property="twitter:image" content="{base_url}/twitter-image.jpg" />

<!-- JSON-LD Structured Data -->
<script type="application/ld+json">
{json_ld}
</script>
```

## Multilingual (hreflang) — Add if i18n enabled
```html
<link rel="alternate" hreflang="en" href="{base_url}/" />
<link rel="alternate" hreflang="ur" href="{base_url}/ur/" />
<link rel="alternate" hreflang="ar" href="{base_url}/ar/" />
<link rel="alternate" hreflang="x-default" href="{base_url}/" />
```

## PWA Meta Tags — Add if PWA enabled
```html
<link rel="manifest" href="/manifest.json" />
<meta name="theme-color" content="#0d9488" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="default" />
<meta name="apple-mobile-web-app-title" content="{pname.replace('-', ' ').title()}" />
```
"""

        # PWA manifest.json
        manifest = f"""{{
  "name": "{pname.replace('-', ' ').title()}",
  "short_name": "{pname[:12].title()}",
  "description": "Professional {industry} platform",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0f172a",
  "theme_color": "#0d9488",
  "orientation": "portrait-primary",
  "icons": [
    {{ "src": "/icons/icon-72x72.png",   "sizes": "72x72",   "type": "image/png" }},
    {{ "src": "/icons/icon-96x96.png",   "sizes": "96x96",   "type": "image/png" }},
    {{ "src": "/icons/icon-128x128.png", "sizes": "128x128", "type": "image/png" }},
    {{ "src": "/icons/icon-144x144.png", "sizes": "144x144", "type": "image/png" }},
    {{ "src": "/icons/icon-152x152.png", "sizes": "152x152", "type": "image/png" }},
    {{ "src": "/icons/icon-192x192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable" }},
    {{ "src": "/icons/icon-384x384.png", "sizes": "384x384", "type": "image/png" }},
    {{ "src": "/icons/icon-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable" }}
  ],
  "categories": ["{industry}"],
  "screenshots": []
}}
"""

        seo_dir = target_dir / "frontend" / "public"
        FileManager.ensure_dir(str(seo_dir))
        FileManager.write_file(str(seo_dir / "robots.txt"),           robots)
        FileManager.write_file(str(seo_dir / "sitemap.xml"),          sitemap)
        FileManager.write_file(str(seo_dir / "manifest.json"),        manifest)
        FileManager.write_file(str(target_dir / "SEO_META_TAGS.md"),  meta_tags_md)
        FileManager.write_file(str(target_dir / "structured-data.json"), json_ld)
        agent_logger.info("SEO files generated: robots.txt, sitemap.xml, manifest.json, SEO_META_TAGS.md, structured-data.json")

    def _generate_cicd_workflow(self, target_dir: Path, plan: Dict[str, Any]) -> None:
        """Generate GitHub Actions CI/CD workflow for automated deploys."""
        pname = plan.get("project_name", "app")

        workflow = f"""\
# ─────────────────────────────────────────────────────────────────
# LumicorePro CI/CD Pipeline — {pname}
# Generated by LumicorePro AI Agent v2.0
# ─────────────────────────────────────────────────────────────────
name: Deploy {pname}

on:
  push:
    branches: [main, master]
  pull_request:
    branches: [main, master]

env:
  NODE_VERSION: "20"
  REGISTRY: ghcr.io
  IMAGE_PREFIX: ${{{{ github.repository_owner }}}}/{pname}

jobs:
  # ── Lint & Test ──────────────────────────────────────────────
  test:
    name: Lint & Test
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{{{ env.NODE_VERSION }}}}
          cache: npm
          cache-dependency-path: frontend/package-lock.json

      - name: Install frontend deps
        run: npm ci
        working-directory: frontend

      - name: Run ESLint
        run: npm run lint
        working-directory: frontend

      - name: Build frontend
        run: npm run build
        working-directory: frontend
        env:
          VITE_API_URL: ${{{{ secrets.VITE_API_URL }}}}

  # ── Deploy Frontend to Vercel ────────────────────────────────
  deploy-frontend:
    name: Deploy Frontend (Vercel)
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main' || github.ref == 'refs/heads/master'
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{{{ secrets.VERCEL_TOKEN }}}}
          vercel-org-id: ${{{{ secrets.VERCEL_ORG_ID }}}}
          vercel-project-id: ${{{{ secrets.VERCEL_PROJECT_ID }}}}
          working-directory: ./frontend
          vercel-args: "--prod"

  # ── Deploy Backend to Render ─────────────────────────────────
  deploy-backend:
    name: Deploy Backend (Render)
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main' || github.ref == 'refs/heads/master'
    steps:
      - name: Trigger Render Deploy
        run: |
          curl -X POST ${{{{ secrets.RENDER_DEPLOY_HOOK_URL }}}}

  # ── Build & Push Docker Images ───────────────────────────────
  docker:
    name: Build Docker Images
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main' || github.ref == 'refs/heads/master'
    permissions:
      contents: read
      packages: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Login to GitHub Container Registry
        uses: docker/login-action@v3
        with:
          registry: ${{{{ env.REGISTRY }}}}
          username: ${{{{ github.actor }}}}
          password: ${{{{ secrets.GITHUB_TOKEN }}}}

      - name: Build & push frontend image
        uses: docker/build-push-action@v5
        with:
          context: ./frontend
          push: true
          tags: ${{{{ env.REGISTRY }}}}/${{{{ env.IMAGE_PREFIX }}}}-frontend:latest

      - name: Build & push backend image
        uses: docker/build-push-action@v5
        with:
          context: ./backend
          push: true
          tags: ${{{{ env.REGISTRY }}}}/${{{{ env.IMAGE_PREFIX }}}}-backend:latest
"""

        github_dir = target_dir / ".github" / "workflows"
        FileManager.ensure_dir(str(github_dir))
        FileManager.write_file(str(github_dir / "deploy.yml"), workflow)
        agent_logger.info("CI/CD workflow generated: .github/workflows/deploy.yml")

    def _generate_deployment_checklist(self, target_dir: Path, plan: Dict[str, Any]) -> None:
        """Generate DEPLOYMENT_CHECKLIST.md — international production launch checklist."""
        pname = plan.get("project_name", "project")
        spec  = plan.get("spec", {}) or {}

        checklist = f"""# ✅ PRODUCTION DEPLOYMENT CHECKLIST — {pname.upper()}

Generated by **LumicorePro AI Agent v2.0**

---

## 🔐 Security (Before going live)
- [ ] Change ALL default passwords and JWT secrets in `.env`
- [ ] Enable HTTPS / SSL certificate (Let's Encrypt or Cloudflare)
- [ ] Set `NODE_ENV=production` on backend
- [ ] Configure CORS to only allow your production domain
- [ ] Enable rate limiting on all API endpoints
- [ ] Run OWASP ZAP security scan
- [ ] Ensure `.env` files are in `.gitignore` — NEVER commit secrets
- [ ] Review all admin routes — require auth middleware

## ⚡ Performance (Before going live)
- [ ] Run `npm run build` — check bundle size < 500KB gzipped
- [ ] Enable Cloudflare CDN or AWS CloudFront
- [ ] Compress images to WebP format
- [ ] Test Lighthouse score ≥ 90 on mobile
- [ ] Enable gzip/brotli compression on Nginx
- [ ] Add `Cache-Control` headers for static assets

## 🌐 SEO & Discoverability
- [ ] Submit `sitemap.xml` to Google Search Console
- [ ] Verify `robots.txt` is accessible at `/robots.txt`
- [ ] Add all Open Graph images (1200×630px)
- [ ] Test Open Graph with https://developers.facebook.com/tools/debug/
- [ ] Test Twitter Card with https://cards-dev.twitter.com/validator
- [ ] Add Google Analytics 4 / Plausible tracking code
- [ ] Add JSON-LD structured data (already generated in `structured-data.json`)

## 📱 Mobile & PWA
- [ ] Test on real mobile devices (iOS Safari + Android Chrome)
- [ ] Verify PWA install prompt works (check `manifest.json`)
- [ ] Test offline mode if PWA enabled
- [ ] Check tap target sizes (minimum 44×44px)
- [ ] Test WhatsApp float button on mobile

## 💳 Payments (if applicable)
- [ ] Switch Stripe from TEST keys to LIVE keys
- [ ] Test full checkout flow with real card
- [ ] Set up Stripe webhook endpoint and verify signature
- [ ] Configure Stripe for correct currency (PKR/USD/EUR)
- [ ] Test refund flow

## 🗄️ Database
- [ ] Run `schema.sql` on production PostgreSQL
- [ ] Set up automated database backups (daily minimum)
- [ ] Create read replica for analytics queries
- [ ] Test database connection pool under load

## 📧 Email & Notifications
- [ ] Configure SMTP (SendGrid/AWS SES/Mailgun) — not localhost
- [ ] Test transactional emails: welcome, reset password, order confirm
- [ ] Set up email monitoring for bounces and spam complaints
- [ ] WhatsApp Business API setup (if using Twilio/360dialog)

## 🔍 Monitoring & Alerts
- [ ] Set up Sentry for error tracking (frontend + backend)
- [ ] Configure uptime monitoring (UptimeRobot / Better Uptime)
- [ ] Set up server resource alerts (CPU > 80%, RAM > 85%)
- [ ] Enable CloudFlare Analytics or similar

## 🚀 CI/CD (GitHub Actions — already generated)
- [ ] Add `VERCEL_TOKEN` to GitHub Secrets
- [ ] Add `RENDER_DEPLOY_HOOK_URL` to GitHub Secrets
- [ ] Add `VITE_API_URL` to GitHub Secrets
- [ ] Test full CI pipeline on a feature branch first

## 🌍 International / Compliance
- [ ] GDPR cookie consent banner is visible on first visit (EU)
- [ ] Privacy Policy and Terms of Service pages published
- [ ] CCPA compliance if serving California users
- [ ] PCI DSS compliance if storing card data (use Stripe — never store raw cards)
- [ ] Verify multilingual content if i18n enabled

## ✅ Final Launch Check
- [ ] All environment variables set in production
- [ ] Test complete user journey: signup → browse → purchase/book → confirm
- [ ] Test on 3 browsers: Chrome, Safari, Firefox
- [ ] Test on iOS and Android mobile
- [ ] Set up domain DNS (A record or CNAME to hosting)
- [ ] Verify HTTPS works and HTTP redirects to HTTPS
- [ ] Announce launch on social media with WhatsApp status 🎉

---

*Checklist generated by LumicorePro AI Agent v2.0 | © 2026 LumicorePro*
"""

        FileManager.write_file(str(target_dir / "DEPLOYMENT_CHECKLIST.md"), checklist)
        agent_logger.info("Deployment checklist generated: DEPLOYMENT_CHECKLIST.md")

    def _generate_instructions_guide(self, target_dir: Path, plan: Dict[str, Any]) -> None:
        """Generate a comprehensive, international-standard INSTRUCTIONS.md file."""
        pname = plan.get("project_name", "generated-project")
        components = plan.get("components", [])
        backend = plan.get("backend", {})
        schemas = plan.get("database_schemas", [])
        spec = plan.get("spec", {})
        website_type = spec.get("website_type", "web") if spec else "web"
        industry = spec.get("industry", "general") if spec else "general"
        features_list = spec.get("features", []) if spec else []

        schema_list = "\n".join([f"   - **{s.get('name')}** — tables: {s.get('tables', '')}" for s in schemas]) or "   - Default schema"
        component_list = "\n".join([f"   - `{c.get('name', 'Component')}`" for c in components[:15]]) or "   - Core UI components"
        features_md = "\n".join([f"   - {f.replace('_', ' ').title()}" for f in features_list[:12]]) or "   - Standard features"

        instructions = f"""# ╔══════════════════════════════════════════════════════════════╗
# ║         LUMICOREPRO — COMPLETE PROJECT INSTRUCTIONS          ║
# ╚══════════════════════════════════════════════════════════════╝

**Project Name:** `{pname}`
**Generated By:** LumicorePro AI Agent v2.0 — 9-Phase Enterprise Pipeline
**Website Type:** {website_type.title()} | **Industry:** {industry.title()}
**Generation Date:** See `generation-report.json`

> This document is your complete guide — from first install to live production.
> Follow every step in order. Each step takes 2–5 minutes.

---

## 📋 TABLE OF CONTENTS

1. [System Requirements](#1-system-requirements)
2. [Project Structure](#2-project-structure)
3. [Frontend Setup](#3-frontend-setup-reactjs--vite)
4. [Backend Setup](#4-backend-setup-nodejs--express)
5. [Database Setup](#5-database-setup-postgresql)
6. [Environment Variables](#6-environment-variables)
7. [Running in Development](#7-running-in-development)
8. [Running in Production](#8-running-in-production)
9. [Cloud Deployment](#9-cloud-deployment)
10. [Docker Setup](#10-docker-setup)
11. [Troubleshooting](#11-troubleshooting)
12. [Project Summary](#12-project-summary)

---

## 1. SYSTEM REQUIREMENTS

Before starting, install these tools on your computer:

| Tool | Minimum Version | Download Link |
|------|----------------|---------------|
| **Node.js** | v18.0.0 or higher | https://nodejs.org/en/download |
| **npm** | v9.0.0 or higher | Comes with Node.js |
| **PostgreSQL** | v14.0 or higher | https://www.postgresql.org/download |
| **Git** | v2.30+ | https://git-scm.com/downloads |

### How to check if installed:
```bash
node --version       # Should print v18.x.x or higher
npm --version        # Should print 9.x.x or higher
psql --version       # Should print 14.x or higher
```

---

## 2. PROJECT STRUCTURE

```
{pname}/
├── frontend/              ← React.js + Vite app (your website UI)
│   ├── src/
│   │   ├── components/    ← {len(components)} UI components
│   │   ├── pages/         ← Main page files
│   │   ├── assets/        ← Images, icons, fonts
│   │   └── App.jsx        ← Root component
│   ├── package.json
│   └── .env.example       ← Copy to .env
│
├── backend/               ← Node.js + Express REST API
│   ├── routes/            ← API route handlers
│   ├── middleware/        ← Auth, rate limiting, CORS
│   ├── server.js          ← Entry point
│   ├── package.json
│   └── .env.example       ← Copy to .env
│
├── database/
│   └── schema.sql         ← PostgreSQL schema (run this first)
│
├── README.md              ← Project overview
└── INSTRUCTIONS.md        ← This file
```

---

## 3. FRONTEND SETUP (React.js + Vite)

### Step 3.1 — Navigate to frontend folder
```bash
cd {pname}/frontend
```

### Step 3.2 — Install all dependencies
```bash
npm install
```
⏳ This downloads all packages. Takes 1–3 minutes.

### Step 3.3 — Create your environment file
```bash
# On Mac/Linux:
cp .env.example .env

# On Windows (Command Prompt):
copy .env.example .env

# On Windows (PowerShell):
Copy-Item .env.example .env
```

### Step 3.4 — Start the development server
```bash
npm run dev
```

✅ **Frontend is live at:** http://localhost:5173

---

## 4. BACKEND SETUP (Node.js + Express)

Open a **new terminal window** (keep the frontend terminal running).

### Step 4.1 — Navigate to backend folder
```bash
cd {pname}/backend
```

### Step 4.2 — Install dependencies
```bash
npm install
```

### Step 4.3 — Create your environment file
```bash
# Mac/Linux:
cp .env.example .env

# Windows PowerShell:
Copy-Item .env.example .env
```

### Step 4.4 — Edit the .env file
Open `backend/.env` and update these values:
```
PORT=5000
DATABASE_URL=postgresql://YOUR_USER:YOUR_PASSWORD@localhost:5432/{pname.replace("-", "_")}_db
JWT_SECRET=your_super_secret_key_here_change_this
```

### Step 4.5 — Start the backend server
```bash
npm run dev
```

✅ **Backend API is live at:** http://localhost:5000
✅ **API Health Check:** http://localhost:5000/health

---

## 5. DATABASE SETUP (PostgreSQL)

### Step 5.1 — Open PostgreSQL
Open **pgAdmin** (GUI) or **terminal/PowerShell** and connect:
```bash
psql -U postgres
```
Enter your PostgreSQL password when prompted.

### Step 5.2 — Create the database
```sql
CREATE DATABASE {pname.replace("-", "_")}_db;
```
Then exit: `\\q`

### Step 5.3 — Run the schema
```bash
# Mac/Linux:
psql -U postgres -d {pname.replace("-", "_")}_db -f database/schema.sql

# Windows PowerShell:
psql -U postgres -d {pname.replace("-", "_")}_db -f database/schema.sql
```

✅ This creates all tables automatically.

### Included SQL Schemas:
{schema_list}

---

## 6. ENVIRONMENT VARIABLES

### Frontend (`frontend/.env`)
```env
VITE_API_URL=http://localhost:5000
VITE_APP_NAME={pname}
VITE_APP_ENV=development
```

### Backend (`backend/.env`)
```env
# Server
PORT=5000
NODE_ENV=development

# Database
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/{pname.replace("-", "_")}_db
DB_HOST=localhost
DB_PORT=5432
DB_NAME={pname.replace("-", "_")}_db
DB_USER=postgres
DB_PASSWORD=YOUR_POSTGRESQL_PASSWORD

# Security — CHANGE THESE IN PRODUCTION
JWT_SECRET=change_this_to_a_random_64_char_string
JWT_EXPIRES_IN=7d
BCRYPT_ROUNDS=12

# CORS
CORS_ORIGIN=http://localhost:5173

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX=100
```

> ⚠️ **NEVER commit your .env file to Git. It's in .gitignore by default.**

---

## 7. RUNNING IN DEVELOPMENT

Run both frontend and backend simultaneously:

**Terminal 1 (Frontend):**
```bash
cd frontend
npm run dev
# → http://localhost:5173
```

**Terminal 2 (Backend):**
```bash
cd backend
npm run dev
# → http://localhost:5000
```

Both servers support **hot reload** — changes appear instantly.

---

## 8. RUNNING IN PRODUCTION

### Frontend — Build for Production
```bash
cd frontend
npm run build
```
Output goes to `frontend/dist/` — this is what you deploy.

### Backend — Production Mode
```bash
cd backend
NODE_ENV=production npm start
```

---

## 9. CLOUD DEPLOYMENT

### Deploy Frontend to Vercel (Recommended — Free)
1. Go to https://vercel.com and sign up
2. Click **"New Project"** → Import your repo
3. Set **Framework Preset**: Vite
4. Set **Root Directory**: `frontend`
5. Add **Environment Variables** (from `frontend/.env.example`)
6. Click **Deploy** ✅

### Deploy Backend to Render (Free Tier Available)
1. Go to https://render.com and sign up
2. Click **"New Web Service"** → Connect repo
3. Set **Root Directory**: `backend`
4. Set **Build Command**: `npm install`
5. Set **Start Command**: `npm start`
6. Add all **Environment Variables** from `backend/.env.example`
7. Deploy ✅

### Deploy Database to Supabase (Free PostgreSQL)
1. Go to https://supabase.com
2. Create new project → copy the **Connection String**
3. Run `database/schema.sql` in the Supabase SQL Editor
4. Update `DATABASE_URL` in your backend env vars

---

## 10. DOCKER SETUP

If you prefer Docker, run everything with one command:

```bash
# From the project root, create docker-compose.yml:
# (Already included if Docker files were generated)

docker-compose up --build
```

Or run individually:
```bash
# Build frontend
docker build -t {pname}-frontend ./frontend

# Build backend
docker build -t {pname}-backend ./backend

# Run backend
docker run -p 5000:5000 --env-file ./backend/.env {pname}-backend

# Run frontend
docker run -p 5173:5173 {pname}-frontend
```

---

## 11. TROUBLESHOOTING

### ❌ `npm install` fails
```bash
# Clear npm cache and retry:
npm cache clean --force
npm install
```

### ❌ Frontend can't connect to backend (CORS error)
- Make sure `CORS_ORIGIN` in `backend/.env` matches your frontend URL exactly
- Both must be running simultaneously

### ❌ PostgreSQL connection refused
- Make sure PostgreSQL service is running:
  ```bash
  # Windows: Check Services app → PostgreSQL should be "Running"
  # Mac: brew services start postgresql
  # Linux: sudo systemctl start postgresql
  ```
- Double-check `DATABASE_URL` in `backend/.env`

### ❌ Port already in use
```bash
# Kill process on port 5000:
# Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Mac/Linux:
lsof -ti:5000 | xargs kill
```

### ❌ `JWT_SECRET` errors
- Make sure you set a proper secret in `backend/.env`
- Minimum 32 characters recommended

### ❌ Build fails with Tailwind errors
```bash
cd frontend
npm install tailwindcss postcss autoprefixer --save-dev
npx tailwindcss init
npm run build
```

---

## 12. PROJECT SUMMARY

| Item | Detail |
|------|--------|
| **Project Name** | {pname} |
| **Website Type** | {website_type.title()} |
| **Industry** | {industry.title()} |
| **Frontend** | React 18 + Vite + Tailwind CSS |
| **Backend** | Node.js + Express.js |
| **Database** | PostgreSQL |
| **Auth** | JWT + bcryptjs |
| **Components** | {len(components)} assembled |
| **API Base** | http://localhost:5000 |
| **Frontend** | http://localhost:5173 |

### ✅ Features Included:
{features_md}

### 📦 Components Included:
{component_list}

---

## 🆘 NEED HELP?

- 📧 **Email:** support@lumicorepro.com
- 📖 **Docs:** https://docs.lumicorepro.com
- 💬 **Discord:** https://discord.gg/lumicorepro
- 🐛 **Issues:** https://github.com/lumicorepro/core/issues

---

*Generated by LumicorePro AI Agent v2.0 — The World's Most Powerful Website Generation System*
*© 2026 LumicorePro. All rights reserved.*
"""
        FileManager.write_file(str(target_dir / "INSTRUCTIONS.md"), instructions)

