"""
Config package initialization.
"""
