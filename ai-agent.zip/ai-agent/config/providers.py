import os
from typing import Dict, Any, List
from .settings import (
    AI_PROVIDER,
    GEMINI_API_KEY,
    DEEPSEEK_API_KEY,
    OPENROUTER_API_KEY,
    GEMINI_MODEL,
    DEEPSEEK_MODEL,
    OPENROUTER_MODEL,
    OPENAI_API_KEY,
    OPENAI_MODEL,
)

# ── New provider keys (read from env at import time) ──────────────────────
ANTHROPIC_API_KEY  = os.getenv("ANTHROPIC_API_KEY", "")
MISTRAL_API_KEY    = os.getenv("MISTRAL_API_KEY", "")
ANTHROPIC_MODEL    = os.getenv("ANTHROPIC_MODEL",  "claude-3-5-sonnet-20241022")
MISTRAL_MODEL      = os.getenv("MISTRAL_MODEL",     "mistral-large-latest")

PROVIDER_CONFIGS: Dict[str, Dict[str, Any]] = {
    # ── Existing providers ─────────────────────────────────────────────
    "gemini": {
        "provider_name": "gemini",
        "api_key": GEMINI_API_KEY,
        "model": GEMINI_MODEL,
        "env_var_name": "GEMINI_API_KEY",
        "class_path": "providers.gemini_provider.GeminiProvider",
    },
    "openai": {
        "provider_name": "openai",
        "api_key": OPENAI_API_KEY,
        "model": OPENAI_MODEL,
        "env_var_name": "OPENAI_API_KEY",
        "class_path": "providers.openai_provider.OpenAIProvider",
    },
    "chatgpt": {
        "provider_name": "openai",
        "api_key": OPENAI_API_KEY,
        "model": OPENAI_MODEL,
        "env_var_name": "OPENAI_API_KEY",
        "class_path": "providers.openai_provider.OpenAIProvider",
    },
    "deepseek": {
        "provider_name": "deepseek",
        "api_key": DEEPSEEK_API_KEY,
        "model": DEEPSEEK_MODEL,
        "env_var_name": "DEEPSEEK_API_KEY",
        "class_path": "providers.deepseek_provider.DeepSeekProvider",
    },
    "openrouter": {
        "provider_name": "openrouter",
        "api_key": OPENROUTER_API_KEY,
        "model": OPENROUTER_MODEL,
        "env_var_name": "OPENROUTER_API_KEY",
        "class_path": "providers.openrouter_provider.OpenRouterProvider",
    },
    # ── New international providers ────────────────────────────────────
    "claude": {
        "provider_name": "claude",
        "api_key": ANTHROPIC_API_KEY,
        "model": ANTHROPIC_MODEL,
        "env_var_name": "ANTHROPIC_API_KEY",
        "class_path": "providers.claude_provider.ClaudeProvider",
    },
    "anthropic": {  # alias so users can write ACTIVE_AI_PROVIDER=anthropic
        "provider_name": "claude",
        "api_key": ANTHROPIC_API_KEY,
        "model": ANTHROPIC_MODEL,
        "env_var_name": "ANTHROPIC_API_KEY",
        "class_path": "providers.claude_provider.ClaudeProvider",
    },
    "mistral": {
        "provider_name": "mistral",
        "api_key": MISTRAL_API_KEY,
        "model": MISTRAL_MODEL,
        "env_var_name": "MISTRAL_API_KEY",
        "class_path": "providers.mistral_provider.MistralProvider",
    },
}

# Priority order: try the cheapest/fastest capable provider first,
# fall back along the chain if key is missing or call fails.
FALLBACK_ORDER: List[str] = [
    "gemini",       # free tier, fast
    "claude",       # best reasoning
    "openai",       # premier standard
    "mistral",      # cheap, multilingual
    "deepseek",     # code-focused
    "openrouter",   # aggregator — last resort
]

def get_active_provider_config(provider_name: str = None) -> Dict[str, Any]:
    """Retrieve configuration for specified or active AI provider (alias-aware)."""
    provider = (provider_name or AI_PROVIDER).lower()
    if provider not in PROVIDER_CONFIGS:
        supported = [k for k in PROVIDER_CONFIGS.keys() if k not in ("anthropic", "chatgpt")]  # hide aliases
        raise ValueError(
            f"Unsupported AI Provider '{provider}'. "
            f"Supported: {supported}"
        )
    return PROVIDER_CONFIGS[provider]


def instantiate_provider(provider_name: str):
    """Dynamically instantiate a provider by name. Returns provider instance or None."""
    try:
        cfg = get_active_provider_config(provider_name)
        p_name = cfg["provider_name"]
        api_key = cfg["api_key"]
        model = cfg["model"]

        if p_name in ("gemini",):
            from providers.gemini_provider import GeminiProvider
            return GeminiProvider(api_key, model)
        elif p_name in ("openai",):
            from providers.openai_provider import OpenAIProvider
            return OpenAIProvider(api_key, model)
        elif p_name in ("deepseek",):
            from providers.deepseek_provider import DeepSeekProvider
            return DeepSeekProvider(api_key, model)
        elif p_name in ("openrouter",):
            from providers.openrouter_provider import OpenRouterProvider
            return OpenRouterProvider(api_key, model)
        elif p_name in ("claude",):
            from providers.claude_provider import ClaudeProvider
            return ClaudeProvider(api_key, model)
        elif p_name in ("mistral",):
            from providers.mistral_provider import MistralProvider
            return MistralProvider(api_key, model)
    except Exception:
        return None


def validate_provider_key(provider_name: str = None, require_key: bool = True) -> bool:
    """Validate that required API key is configured for the selected provider."""
    cfg = get_active_provider_config(provider_name)
    key = cfg.get("api_key", "").strip()

    placeholder_keys = {
        "your_gemini_api_key_here",
        "your_openai_api_key_here",
        "your_deepseek_api_key_here",
        "your_openrouter_api_key_here",
        "your_anthropic_api_key_here",
        "your_mistral_api_key_here",
        "",
    }

    # Accept both old (AIza...) and new (AQ.Ab8...) Gemini key formats
    key_valid = key not in placeholder_keys or key.startswith("AQ.")

    if not key_valid:
        if require_key:
            raise ValueError(
                f"\n[CONFIGURATION ERROR] API key for provider '{cfg['provider_name']}' "
                f"is missing or invalid.\n"
                f"Please set '{cfg['env_var_name']}' in your 'ai-agent/.env' file."
            )
        return False
    return True


def get_available_providers() -> List[str]:
    """Return list of providers that have a configured (non-placeholder) API key."""
    available = []
    for name in FALLBACK_ORDER:
        try:
            if validate_provider_key(name, require_key=False):
                available.append(name)
        except Exception:
            pass
    return available
