import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    env_path = Path(__file__).resolve().parent.parent.parent / ".env"
    if not env_path.exists():
        env_path = Path(__file__).resolve().parent.parent / ".env"
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
except ImportError:
    pass

# Base Paths (Normalizing workspace root path)
AI_AGENT_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = AI_AGENT_DIR.parent.resolve()

# Specific Directories
REGISTRY_DIR = (PROJECT_ROOT / "registry").resolve()
GENERATED_PROJECTS_DIR = (PROJECT_ROOT / "generated-projects").resolve()
TEMPLATES_DIR = (PROJECT_ROOT / "src" / "templates").resolve()
COMPONENTS_DIR = (PROJECT_ROOT / "src" / "components").resolve()
BACKEND_LIBRARY_DIR = (PROJECT_ROOT / "backend-library").resolve()
DATABASE_SCHEMAS_DIR = (PROJECT_ROOT / "database" / "schemas").resolve()
ASSETS_DIR = (PROJECT_ROOT / "src" / "assets").resolve()
ICONS_DIR = (PROJECT_ROOT / "src" / "icons").resolve()
STYLES_DIR = (PROJECT_ROOT / "src" / "styles").resolve()

# Database & Memory
AGENT_DB_PATH = (AI_AGENT_DIR / "database" / "agent.db").resolve()

# AI Configuration
AI_PROVIDER = os.getenv("ACTIVE_AI_PROVIDER", os.getenv("AI_PROVIDER", "gemini")).lower()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")
OPENROUTER_MODEL = os.getenv("OPENROUTER_MODEL", "deepseek/deepseek-chat")

ALLOW_AI_FALLBACK = os.getenv("ALLOW_AI_FALLBACK", "true").lower() == "true"

# ── Anthropic Claude ───────────────────────────────────────────────────────
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL   = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")

# ── Mistral ────────────────────────────────────────────────────────────────
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "")
MISTRAL_MODEL   = os.getenv("MISTRAL_MODEL", "mistral-large-latest")

# ── OpenAI ─────────────────────────────────────────────────────────────────
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL   = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1/chat/completions")
