"""
LumicorePro AI Agent — FastAPI WebSocket Server
================================================
Exposes the 9-phase generation pipeline over HTTP + WebSocket so the React
frontend can stream real-time progress updates without polling.

Endpoints
---------
GET  /health                   — liveness probe
GET  /api/registries/summary   — template/component/asset counts from SQLite
POST /api/generate             — fire-and-forget generation (returns run_id)
WS   /ws/generate/{run_id}     — streams phase events as JSON lines
POST /api/dry-run              — returns the assembly plan without writing files
GET  /api/history              — last 20 generation records from SQLite

Usage
-----
    cd ai-agent
    uvicorn server:app --host 0.0.0.0 --port 8000 --reload

Or from project root:
    python ai-agent/server.py
"""

import sys
import os
import uuid
import json
import asyncio
import time
import sqlite3
import secrets
from pathlib import Path
from typing import Optional, Dict, Any, List
from collections import defaultdict
from datetime import datetime, timedelta

# ── Path bootstrap ─────────────────────────────────────────────────────────
AI_AGENT_DIR = Path(__file__).resolve().parent
if str(AI_AGENT_DIR) not in sys.path:
    sys.path.insert(0, str(AI_AGENT_DIR))

try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks, Request, Depends, Header
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.trustedhost import TrustedHostMiddleware
    from fastapi.responses import JSONResponse, FileResponse
    from pydantic import BaseModel, Field
except ImportError:
    print("[ERROR] FastAPI not installed. Run: pip install fastapi uvicorn websockets")
    sys.exit(1)

from config.settings import AGENT_DB_PATH, GENERATED_PROJECTS_DIR
from database.init_db import init_database
from utils.logger import agent_logger

# ── FastAPI app ────────────────────────────────────────────────────────────
app = FastAPI(
    title="LumicorePro AI Agent API",
    description="Real-time 10-phase international website generation pipeline with WebSocket streaming",
    version="3.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── Allowed origins ────────────────────────────────────────────────────────
_ALLOWED_ORIGINS = [
    o.strip()
    for o in os.getenv(
        "CORS_ORIGINS",
        "http://localhost:5173,http://localhost:3000,http://127.0.0.1:5173",
    ).split(",")
    if o.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# ── In-memory rate limiter ─────────────────────────────────────────────────
# Format: { ip: [(timestamp, endpoint), ...] }
_rate_store: Dict[str, List[float]] = defaultdict(list)
_RATE_LIMIT  = int(os.getenv("RATE_LIMIT_REQUESTS", "30"))   # requests
_RATE_WINDOW = int(os.getenv("RATE_LIMIT_WINDOW",   "60"))   # seconds

def _check_rate_limit(client_ip: str) -> bool:
    """Return True if request is allowed, False if rate-limited."""
    now = time.time()
    window_start = now - _RATE_WINDOW
    _rate_store[client_ip] = [t for t in _rate_store[client_ip] if t > window_start]
    if len(_rate_store[client_ip]) >= _RATE_LIMIT:
        return False
    _rate_store[client_ip].append(now)
    return True

def _get_client_ip(request: Request) -> str:
    direct_ip = request.client.host if request.client else "unknown"
    trusted_proxies = {
        value.strip()
        for value in os.getenv("TRUSTED_PROXY_IPS", "").split(",")
        if value.strip()
    }
    if direct_ip in trusted_proxies:
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return direct_ip

# ── Simple API-key auth (optional — set AGENT_API_KEY env to enable) ───────
_AGENT_API_KEY = os.getenv("AGENT_API_KEY", "").strip()

def _verify_api_key(x_api_key: Optional[str] = Header(default=None)) -> bool:
    """If AGENT_API_KEY is configured, validate incoming key header."""
    if not _AGENT_API_KEY:
        return True  # Auth disabled
    if not x_api_key or not secrets.compare_digest(x_api_key, _AGENT_API_KEY):
        raise HTTPException(status_code=401, detail="Invalid or missing API key")
    return True

# ── In-memory run registry ─────────────────────────────────────────────────
# Maps run_id → {"status": str, "events": list, "result": dict | None}
_runs: Dict[str, Dict[str, Any]] = {}
_idempotency_store: Dict[str, tuple] = {}
_MAX_RUNS = max(10, int(os.getenv("AGENT_MAX_RUNS", "100")))
_MAX_EVENTS = max(20, int(os.getenv("AGENT_MAX_EVENTS", "500")))
_MAX_CONCURRENT_RUNS = max(1, int(os.getenv("AGENT_MAX_CONCURRENT_RUNS", "2")))
_run_semaphore = asyncio.Semaphore(_MAX_CONCURRENT_RUNS)


def _cleanup_run_state() -> None:
    """Bound process-local state so long-lived API workers do not grow forever."""
    if len(_runs) <= _MAX_RUNS:
        return
    finished = sorted(
        (
            (run_id, run.get("finished_at", run.get("created_at", "")))
            for run_id, run in _runs.items()
            if run.get("status") in {"done", "error"}
        ),
        key=lambda item: item[1],
    )
    for run_id, _ in finished[: max(0, len(_runs) - _MAX_RUNS)]:
        _runs.pop(run_id, None)

    for key, (run_id, created_at) in list(_idempotency_store.items()):
        if run_id not in _runs or time.time() - created_at > 86400:
            _idempotency_store.pop(key, None)

# ── Pydantic models ────────────────────────────────────────────────────────
class GenerateRequest(BaseModel):
    prompt: str = Field(..., min_length=5, max_length=2000, description="Natural language website description")
    provider: Optional[str] = Field("gemini", description="AI provider: gemini | claude | mistral | deepseek | openrouter")
    dry_run: bool = Field(False, description="If true, return plan without writing files")
    language: Optional[str] = Field("en", description="UI language code: en, ar, ur, fr, de, es, zh, ...")
    region: Optional[str] = Field(None, description="Target region: NA, EU, SA, MENA, APAC, AF, LATAM")


class DryRunRequest(BaseModel):
    prompt: str = Field(..., min_length=5, max_length=2000)
    provider: Optional[str] = "gemini"


class LocalizeRequest(BaseModel):
    prompt: str = Field(..., min_length=5, max_length=2000, description="Website prompt to detect region/currency from")
    region: Optional[str] = Field(None, description="Override region detection: NA|EU|SA|MENA|APAC|AF|LATAM")


class ComplianceRequest(BaseModel):
    region: str = Field("NA", description="Region code: NA|EU|SA|MENA|APAC|AF|LATAM")
    website_type: Optional[str] = Field("ecommerce", description="Website type for regulation scoping")
    project_name: Optional[str] = Field("My Project")


# ── Background generation task ─────────────────────────────────────────────
async def _run_pipeline(run_id: str, prompt: str, provider: Optional[str]):
    """Execute the 9-phase pipeline in a thread and stream events."""
    run = _runs[run_id]
    async with _run_semaphore:
        run["status"] = "running"
        run["started_at"] = time.time()

        def _emit(event_type: str, data: dict):
            event = {"run_id": run_id, "type": event_type, "ts": time.time(), **data}
            run["events"].append(event)
            del run["events"][:-_MAX_EVENTS]

        try:
            # Import inside function so server starts even if agent deps are missing
            from agent.orchestrator import AgentOrchestrator

            loop = asyncio.get_event_loop()

            # We run the synchronous orchestrator in a thread pool to keep the
            # event loop free for WebSocket heartbeats.
            def _sync_run():
                orchestrator = AgentOrchestrator(provider_name=provider)

                # Pre-emit all phases as pending
                for idx, phase in enumerate(orchestrator.PHASES):
                    _emit("phase_pending", {"phase": phase, "index": idx})

                def _on_progress(phase_name: str, event_type: str, data: dict):
                    _emit(event_type, {"phase": phase_name, **data})

                return orchestrator.run(prompt, interactive=False, progress_callback=_on_progress)

            report = await loop.run_in_executor(None, _sync_run)
            run["result"] = report
            run["status"] = "done"
            run["finished_at"] = time.time()
            _emit("complete", {"project_name": report.get("project_name"), "quality_score": report.get("quality_gates", {}).get("overall_score"), "zip": report.get("zip_archive_path")})

            # Persist to generation_history
            _persist_history(prompt, provider, report)

        except Exception as exc:
            agent_logger.error(f"Pipeline run {run_id} failed: {exc}", exc_info=True)
            run["status"] = "error"
            run["finished_at"] = time.time()
            run["error"] = "Generation failed. Check the run report for details."
            _emit("error", {"message": run["error"]})


def _persist_history(prompt: str, provider: str, report: dict):
    try:
        if not os.path.exists(AGENT_DB_PATH):
            return
        conn = sqlite3.connect(str(AGENT_DB_PATH))
        conn.execute(
            "INSERT INTO generation_history (project_name, prompt, template_used, status, report_json) VALUES (?,?,?,?,?)",
            (report.get("project_name", ""), prompt, report.get("selected_resources", {}).get("template", ""), "complete", json.dumps(report))
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


# ── Routes ─────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    if not os.path.exists(AGENT_DB_PATH):
        init_database()
    agent_logger.info("LumicorePro FastAPI server started.")


@app.get("/health", tags=["System"])
async def health():
    return {"status": "ok", "version": "3.0.0", "agent": "LumicorePro 10-Phase International Pipeline"}


@app.get("/api/providers", tags=["System"])
async def list_providers():
    """Return all configured AI providers and which ones have valid API keys."""
    try:
        from config.providers import get_available_providers, FALLBACK_ORDER, PROVIDER_CONFIGS
        available = get_available_providers()
        providers_info = []
        for name in FALLBACK_ORDER:
            cfg = PROVIDER_CONFIGS.get(name, {})
            providers_info.append({
                "name": name,
                "model": cfg.get("model", ""),
                "available": name in available,
                "env_var": cfg.get("env_var_name", ""),
            })
        return {"providers": providers_info, "available_count": len(available)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/api/languages", tags=["Internationalization"])
async def list_languages():
    """Return all 40+ supported UI languages with metadata."""
    from agent.localization_engine import LocalizationEngine
    engine = LocalizationEngine()
    return {
        "languages": [
            {"code": code, **meta}
            for code, meta in engine.LANGUAGES.items()
        ],
        "total": len(engine.LANGUAGES),
        "rtl_languages": [c for c, m in engine.LANGUAGES.items() if m["dir"] == "rtl"],
    }


@app.get("/api/currencies", tags=["Internationalization"])
async def list_currencies(region: Optional[str] = None):
    """Return currency definitions. Optionally filter by region: SA|MENA|EU|NA|APAC|AF|LATAM"""
    from agent.currency_localizer import CurrencyLocalizer
    localizer = CurrencyLocalizer()
    currencies = localizer.CURRENCIES
    if region:
        currencies = {k: v for k, v in currencies.items() if v.get("region") == region}
    return {
        "currencies": currencies,
        "total": len(currencies),
        "rtl_currencies": localizer.list_rtl_currencies(),
    }


@app.post("/api/localize", tags=["Internationalization"])
async def localize(req: LocalizeRequest, request: Request, _auth: bool = Depends(_verify_api_key)):
    """Detect region & currency from a prompt, return full localization config."""
    client_ip = _get_client_ip(request)
    if not _check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Rate limit exceeded. Try again in a minute.")
    try:
        from agent.currency_localizer import CurrencyLocalizer
        from agent.localization_engine import LocalizationEngine
        from agent.requirement_analyzer import RequirementAnalyzer

        analyzer = RequirementAnalyzer()
        spec = analyzer._local_rule_analysis(req.prompt)
        if req.region:
            spec["region"] = req.region

        currency_result = CurrencyLocalizer().localize(spec)
        i18n_langs = LocalizationEngine()._select_languages({**spec, "region": currency_result["region"]})

        return {
            "region":               currency_result["region"],
            "primary_currency":     currency_result["primary_currency"],
            "supported_currencies": currency_result["supported_currencies"],
            "payment_gateways":     currency_result["payment_gateways"],
            "tax":                  currency_result["tax"],
            "locale_settings":      currency_result["locale_settings"],
            "compliance_flags":     currency_result["compliance_flags"],
            "recommended_languages": i18n_langs[:10],
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/api/compliance", tags=["Internationalization"])
async def compliance_info(req: ComplianceRequest, request: Request, _auth: bool = Depends(_verify_api_key)):
    """Return applicable regulations and compliance requirements for a region."""
    client_ip = _get_client_ip(request)
    if not _check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Rate limit exceeded.")
    try:
        from agent.compliance_generator import ComplianceGenerator
        gen = ComplianceGenerator()
        spec = {"website_type": req.website_type, "project_name": req.project_name}
        applicable = gen._get_applicable_regs(req.region, spec)
        return {
            "region": req.region,
            "regulations": [
                {
                    "code":         r["code"],
                    "full_name":    r["full_name"],
                    "jurisdictions":r["jurisdictions"],
                    "cookie_policy":r.get("cookie_policy"),
                    "penalty":      r.get("penalty"),
                    "requirements": r["requirements"],
                    "key_rights":   r["key_rights"],
                }
                for r in applicable
            ],
            "cookie_model":        gen._get_cookie_model(applicable),
            "requires_consent_banner": any(
                r.get("cookie_policy", "").startswith("Opt-in") for r in applicable
            ),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/api/registries/summary", tags=["Registry"])
async def registries_summary():
    """Return counts of all indexed templates, components, assets, etc."""
    if not os.path.exists(AGENT_DB_PATH):
        raise HTTPException(status_code=503, detail="Database not initialized. Call /api/init first.")
    try:
        conn = sqlite3.connect(str(AGENT_DB_PATH))
        tables = {
            "templates":  "templates_index",
            "components": "components_index",
            "assets":     "assets_index",
            "backends":   "backend_index",
            "schemas":    "database_schemas_index",
        }
        summary = {}
        for key, tbl in tables.items():
            try:
                row = conn.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()
                summary[key] = row[0] if row else 0
            except Exception:
                summary[key] = 0
        conn.close()
        return {"summary": summary}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/api/generate", tags=["Generation"])
async def generate(req: GenerateRequest, request: Request, background_tasks: BackgroundTasks, _auth: bool = Depends(_verify_api_key)):
    """Start a generation run. Returns run_id immediately; connect to /ws/generate/{run_id} for streaming."""
    client_ip = _get_client_ip(request)
    if not _check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Rate limit exceeded. Max 30 requests/minute per IP.")

    idempotency_key = request.headers.get("Idempotency-Key", "").strip()
    if len(idempotency_key) > 128:
        raise HTTPException(status_code=400, detail="Idempotency-Key is too long.")
    if idempotency_key:
        existing = _idempotency_store.get(idempotency_key)
        if existing and existing[0] in _runs:
            existing_run = _runs[existing[0]]
            return {
                "run_id": existing[0],
                "status": existing_run["status"],
                "ws_url": f"/ws/generate/{existing[0]}",
                "language": existing_run.get("language", "en"),
                "region": existing_run.get("region"),
                "idempotent_replay": True,
            }

    run_id = str(uuid.uuid4())
    _runs[run_id] = {
        "status": "queued", "events": [], "result": None, "error": None,
        "language": req.language or "en",
        "region": req.region,
        "created_at": datetime.utcnow().isoformat(),
    }
    _cleanup_run_state()
    if idempotency_key:
        _idempotency_store[idempotency_key] = (run_id, time.time())
    background_tasks.add_task(_run_pipeline, run_id, req.prompt, req.provider)
    return {
        "run_id": run_id,
        "status": "queued",
        "ws_url": f"/ws/generate/{run_id}",
        "language": req.language,
        "region": req.region,
    }


@app.post("/api/dry-run", tags=["Generation"])
async def dry_run(req: DryRunRequest, _auth: bool = Depends(_verify_api_key)):
    """Return the assembly plan without writing files."""
    import asyncio
    from agent.orchestrator import AgentOrchestrator

    loop = asyncio.get_event_loop()

    def _sync():
        orchestrator = AgentOrchestrator(provider_name=req.provider)
        spec = orchestrator.analyzer.analyze(req.prompt)
        template = orchestrator.template_selector.select_template(spec)
        components = orchestrator.component_selector.select_components(spec)
        assets = orchestrator.asset_selector.select_assets(spec)
        backend = orchestrator.backend_selector.select_backend(spec)
        schemas = orchestrator.database_selector.select_schemas(spec)
        plan = orchestrator.planner.create_plan(spec, template, components, assets, backend, schemas)
        return {
            "project_name": plan.get("project_name"),
            "website_type": spec.get("website_type"),
            "industry": spec.get("industry"),
            "template": template.get("name") if template else "Default",
            "components_count": len(components),
            "components": [c["name"] for c in components],
            "backend": backend.get("name") if backend else "Default Express",
            "schemas": [s.get("name") for s in schemas],
            "assembly_steps": len(plan.get("assembly_steps", [])),
            "ai_tasks": len(plan.get("ai_tasks_required", [])),
            "features": spec.get("features", []),
        }

    try:
        plan_summary = await loop.run_in_executor(None, _sync)
        return plan_summary
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/api/runs/{run_id}", tags=["Generation"])
async def get_run(run_id: str, _auth: bool = Depends(_verify_api_key)):
    run = _runs.get(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return {"run_id": run_id, "status": run["status"], "events_count": len(run["events"]), "result": run.get("result"), "error": run.get("error")}


@app.get("/api/download/{run_id}", tags=["Generation"])
async def download_run_zip(run_id: str, _auth: bool = Depends(_verify_api_key)):
    """Download the generated project ZIP file for a given run_id."""
    run = _runs.get(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    
    result = run.get("result") or {}
    zip_path = result.get("zip_archive_path")
    
    if zip_path:
        try:
            zip_path = str(Path(zip_path).resolve())
            zip_root = GENERATED_PROJECTS_DIR.resolve()
            Path(zip_path).relative_to(zip_root)
        except (OSError, ValueError):
            zip_path = ""

    if not zip_path or not os.path.exists(zip_path):
        project_name = result.get("project_name", run_id)
        candidates = list(GENERATED_PROJECTS_DIR.glob(f"*{project_name}*.zip"))
        if candidates:
            zip_path = str(candidates[0])
            
    if not zip_path or not os.path.exists(zip_path):
        raise HTTPException(status_code=404, detail="Generated ZIP file not found or generation not complete.")
        
    filename = os.path.basename(zip_path)
    return FileResponse(
        path=zip_path,
        media_type="application/zip",
        filename=filename,
    )


@app.get("/api/history", tags=["Generation"])
async def history(limit: int = 20, _auth: bool = Depends(_verify_api_key)):
    """Return last N generation records."""
    limit = max(1, min(limit, 100))
    if not os.path.exists(AGENT_DB_PATH):
        return {"history": []}
    try:
        conn = sqlite3.connect(str(AGENT_DB_PATH))
        rows = conn.execute(
            "SELECT id, project_name, prompt, status, created_at FROM generation_history ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
        conn.close()
        return {"history": [{"id": r[0], "project_name": r[1], "prompt": r[2][:80], "status": r[3], "created_at": r[4]} for r in rows]}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.websocket("/ws/generate/{run_id}")
async def ws_generate(websocket: WebSocket, run_id: str):
    """
    Stream phase events for a given run_id.
    Client receives JSON messages: {"type": "phase_start"|"phase_done"|"complete"|"error", ...}
    """
    if _AGENT_API_KEY:
        provided_key = websocket.headers.get("x-api-key")
        if not provided_key or not secrets.compare_digest(provided_key, _AGENT_API_KEY):
            await websocket.close(code=1008, reason="Invalid or missing API key")
            return

    await websocket.accept()

    if run_id not in _runs:
        await websocket.send_json({"type": "error", "message": f"Run {run_id} not found"})
        await websocket.close()
        return

    run = _runs[run_id]
    sent_idx = 0

    try:
        while True:
            # Send any new events since last check
            events = run["events"]
            while sent_idx < len(events):
                await websocket.send_json(events[sent_idx])
                sent_idx += 1

            if run["status"] in ("done", "error"):
                # Flush remaining events
                while sent_idx < len(run["events"]):
                    await websocket.send_json(run["events"][sent_idx])
                    sent_idx += 1
                # Send final summary
                await websocket.send_json({
                    "type": "finished",
                    "run_id": run_id,
                    "status": run["status"],
                    "result": run.get("result"),
                    "error": run.get("error"),
                })
                break

            await asyncio.sleep(0.15)  # 150ms polling cadence

    except WebSocketDisconnect:
        agent_logger.info(f"WebSocket client disconnected from run {run_id}")
    except Exception as exc:
        agent_logger.error(f"WebSocket error for run {run_id}: {exc}")
        try:
            await websocket.send_json({"type": "error", "message": str(exc)})
        except Exception:
            pass


# ── Dev entry point ────────────────────────────────────────────────────────
if __name__ == "__main__":
    try:
        import uvicorn
        uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True, log_level="info")
    except ImportError:
        print("uvicorn not installed. Run: pip install uvicorn[standard]")
